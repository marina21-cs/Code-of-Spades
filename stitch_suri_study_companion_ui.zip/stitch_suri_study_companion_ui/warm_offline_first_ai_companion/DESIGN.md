---
name: Suri Atmospheric
colors:
  surface: '#fff8f5'
  surface-dim: '#e1d8d4'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf2ed'
  surface-container: '#f5ece7'
  surface-container-high: '#efe6e2'
  surface-container-highest: '#e9e1dc'
  on-surface: '#1e1b18'
  on-surface-variant: '#57423b'
  inverse-surface: '#34302d'
  inverse-on-surface: '#f8efea'
  outline: '#8b7269'
  outline-variant: '#dec0b6'
  surface-tint: '#a33e11'
  primary: '#a03b0e'
  on-primary: '#ffffff'
  primary-container: '#c15326'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59a'
  secondary: '#615e56'
  on-secondary: '#ffffff'
  secondary-container: '#e4dfd5'
  on-secondary-container: '#65625a'
  tertiary: '#016576'
  on-tertiary: '#ffffff'
  tertiary-container: '#2e7e90'
  on-tertiary-container: '#f9fdff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#380d00'
  on-primary-fixed-variant: '#812900'
  secondary-fixed: '#e7e2d8'
  secondary-fixed-dim: '#cbc6bc'
  on-secondary-fixed: '#1d1c15'
  on-secondary-fixed-variant: '#49473f'
  tertiary-fixed: '#aaedff'
  tertiary-fixed-dim: '#87d2e5'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#fff8f5'
  on-background: '#1e1b18'
  surface-variant: '#e9e1dc'
  surface-warm: '#fbf2ed'
  primary-gradient-start: '#e06a3b'
  primary-gradient-end: '#c8552b'
  glass-bg: rgba(255, 255, 255, 0.8)
  glass-border: rgba(255, 255, 255, 0.6)
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Fira Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Fira Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Fira Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Fira Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  container-max: 1120px
---

## Brand & Style

Suri Atmospheric is a warm, educational brand designed to feel approachable, optimistic, and gentle. The brand identity centers on a "friendly companion" mascot, using soft transitions and organic movements to reduce user anxiety, particularly in edge cases like being offline.

The design style is a blend of **Glassmorphism** and **Modern Soft UI**. It utilizes high-transparency frosted layers (backdrop-blur) and soft gradients to create a sense of lightness and depth. The aesthetic is intentionally "atmospheric," using subtle shader-inspired backgrounds to maintain a living, breathing interface even when data is static. The emotional goal is to evoke a sense of calm focus and reliability through rounded forms and a harmonious, warm color palette.

## Colors

The palette is anchored by a vibrant, earthy **Terracotta Primary (#e06a3b)**, which provides energy and focus. This is supported by a sophisticated **Warm Grey Secondary** and a **Deep Teal Tertiary** for functional accents.

The background system avoids pure white, opting for a layered "Warm Surface" strategy. The base background is a very light peach-white, while interactive containers use semi-transparent white with high blur to achieve a glass effect. Primary actions utilize a vertical linear gradient to create a subtle tactile "lift" compared to flat elements. Text uses a high-contrast dark charcoal to ensure readability against the warm, tinted backgrounds.

## Typography

The system uses a dual-font approach. **Plus Jakarta Sans** is the hero font, used for headings and display text; its soft, rounded terminals reinforce the friendly brand personality. **Fira Sans** is used for body copy and labels, chosen for its high legibility and professional, humanist structure.

Headlines should use heavy weights (Bold to Extrabold) and tight letter-spacing to create a strong visual anchor. Body text uses generous line heights (1.5x) and slight letter-spacing to improve reading stamina in educational contexts. For mobile screens, display sizes should scale down roughly 20% to maintain visual balance.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy for centralized content (like modals or focused cards) and a **Fluid Grid** for dashboard views. A base unit of 8px (with a 4px sub-grid) defines the spatial rhythm.

Standard mobile views should utilize 24px (gutter) side margins. Components within cards are separated by 16px (sm) or 24px (md) gaps. Large vertical sections, such as the space between a mascot/illustration and a headline, use 64px (xl) to create clear visual separation. Containers should have a maximum width of 400px for focused content or 1120px for full-page layouts.

## Elevation & Depth

Hierarchy is established through **Glassmorphism** and **Ambient Shadows**. 

1.  **The Base Layer:** A soft, animated shader or gradient background that provides movement without distraction.
2.  **The Glass Layer:** Primary content containers use an 80% opaque white background with a 20px+ backdrop-blur. A subtle 1px border at 60% opacity white creates a "rim light" effect, simulating physical glass.
3.  **Soft Elevation:** Components use extremely diffused, low-opacity shadows (e.g., `0 8px 32px rgba(0,0,0,0.05)`) to feel nested rather than floating high above the surface.
4.  **Interactive States:** Hovering or focusing elements should increase shadow spread and slightly brighten the background color to signify interactivity.

## Shapes

The shape language is highly organic and friendly, characterized by large border radii. 

-   **Main Containers:** Use a `2rem` (32px) radius to create a soft, non-intimidating frame for content.
-   **Buttons & Chips:** Use a `full` (pill-shaped) radius. This reinforces the playful, approachable nature of the brand.
-   **Secondary Cards:** Use a `1rem` (16px) radius to distinguish them from the primary container and the buttons.

## Components

### Buttons
-   **Primary:** Pill-shaped, featuring a vertical terracotta gradient, white text, and a soft shadow. On hover, apply a slight brightness increase.
-   **Secondary:** Pill-shaped, transparent background with a thin `outline-variant` border. Uses `on-surface` text color.

### Cards & Containers
-   Always use the Glassmorphism style: `bg-white/80`, `backdrop-blur-xl`, and `border-white/60`.
-   Padding should be generous (typically `py-10 px-gutter`).

### Mascot / Illustrations
-   Illustrations should be centered and given room to breathe.
-   Incorporate subtle "breathing" or "wiggle" animations (3s duration, ease-in-out) to keep the interface feeling alive during idle states.

### Interaction States
-   **Focus Rings:** Use a 4px offset ring using the `primary-container` color for high visibility.
-   **Transitions:** All state changes (hover, active) should use a `300ms transition-all` duration with a standard cubic-bezier curve.
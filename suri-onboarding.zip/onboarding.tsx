/**
 * Onboarding pager — single-file that manages the full 6-screen onboarding flow.
 *
 * Uses react-native-pager-view for native swipe navigation.
 * State (grade, mode, page) is managed locally via useReducer.
 * Screen sub-components receive props and call callbacks up.
 * Profile is persisted only on final completion (Screen 6 CTA).
 */
import { useCallback, useEffect, useReducer, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import PagerView from 'react-native-pager-view';
import { useRouter } from 'expo-router';

import { markFirstRunComplete, saveProfile } from '@/profile/profileStore';
import type { LearningProfile, ResponseMode } from '@/profile/types';

import { trackOnboardingEvent } from '@/onboarding/analytics';
import { ProgressDots } from '@/onboarding/components/ProgressDots';
import { CurriculumScreen } from '@/onboarding/screens/CurriculumScreen';
import { DemoScreen } from '@/onboarding/screens/DemoScreen';
import { GradeScreen } from '@/onboarding/screens/GradeScreen';
import { ModeScreen } from '@/onboarding/screens/ModeScreen';
import { OfflineScreen } from '@/onboarding/screens/OfflineScreen';
import { WelcomeScreen } from '@/onboarding/screens/WelcomeScreen';
import { useReduceMotion } from '@/onboarding/useReduceMotion';
import type { OnboardingAction, OnboardingState } from '@/onboarding/types';

// ---------------------------------------------------------------------------
// State Management
// ---------------------------------------------------------------------------

const initialState: OnboardingState = {
  gradeLevel: null,
  responseMode: null,
  currentPage: 0,
  startTimestamp: Date.now(),
};

function reducer(state: OnboardingState, action: OnboardingAction): OnboardingState {
  switch (action.type) {
    case 'SET_GRADE':
      return { ...state, gradeLevel: action.grade };
    case 'SET_MODE':
      return { ...state, responseMode: action.mode };
    case 'GO_TO_PAGE':
      return { ...state, currentPage: action.page };
    case 'RESET_MODE':
      return { ...state, responseMode: null };
    default:
      return state;
  }
}

// ---------------------------------------------------------------------------
// Pager Component
// ---------------------------------------------------------------------------

export default function OnboardingPager() {
  const router = useRouter();
  const reduceMotion = useReduceMotion();
  const pagerRef = useRef<PagerView>(null);
  const [state, dispatch] = useReducer(reducer, initialState);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(false);

  // Track TTS/SVG status for analytics
  const ttsPlayedRef = useRef(false);
  const svgRenderedRef = useRef(false);
  // Track previous page for detecting back-navigation (avoids stale closure)
  const prevPageRef = useRef(0);

  // Track onboarding_started on mount
  useEffect(() => {
    void trackOnboardingEvent({ name: 'onboarding_started', timestamp: Date.now() });
  }, []);

  // ---------------------------------------------------------------------------
  // Navigation helpers
  // ---------------------------------------------------------------------------

  const goToPage = useCallback((page: number) => {
    pagerRef.current?.setPage(page);
    dispatch({ type: 'GO_TO_PAGE', page });
  }, []);

  const handlePageSelected = useCallback(
    (e: { nativeEvent: { position: number } }) => {
      const newPage = e.nativeEvent.position;
      const prevPage = prevPageRef.current;
      prevPageRef.current = newPage;
      dispatch({ type: 'GO_TO_PAGE', page: newPage });

      // Reset mode when swiping BACK to page 3 (mode picker)
      if (newPage === 3 && prevPage === 4) {
        dispatch({ type: 'RESET_MODE' });
      }

      // Track page-specific analytics
      if (newPage === 1) {
        void trackOnboardingEvent({ name: 'onboarding_offline_viewed', timestamp: Date.now() });
      }
    },
    [],
  );

  // ---------------------------------------------------------------------------
  // Screen callbacks
  // ---------------------------------------------------------------------------

  const handleGradeSelect = useCallback(
    (grade: number) => {
      dispatch({ type: 'SET_GRADE', grade });
      void trackOnboardingEvent({
        name: 'onboarding_grade_selected',
        grade,
        timestamp: Date.now(),
      });
    },
    [],
  );

  const handleModeSelect = useCallback(
    (mode: ResponseMode) => {
      dispatch({ type: 'SET_MODE', mode });
      void trackOnboardingEvent({
        name: 'onboarding_mode_selected',
        mode,
        wasSkip: false,
        timestamp: Date.now(),
      });
      // Auto-advance to demo screen
      goToPage(4);
    },
    [goToPage],
  );

  const handleModeSkip = useCallback(() => {
    dispatch({ type: 'SET_MODE', mode: 'mixed' });
    void trackOnboardingEvent({
      name: 'onboarding_mode_selected',
      mode: 'mixed',
      wasSkip: true,
      timestamp: Date.now(),
    });
    goToPage(4);
  }, [goToPage]);

  const handleDemoNext = useCallback(() => {
    void trackOnboardingEvent({
      name: 'onboarding_demo_played',
      grade: state.gradeLevel ?? 6,
      mode: state.responseMode ?? 'mixed',
      ttsPlayed: ttsPlayedRef.current,
      svgRendered: svgRenderedRef.current,
    });
    goToPage(5);
  }, [state.gradeLevel, state.responseMode, goToPage]);

  const handleComplete = useCallback(async () => {
    if (saving) return;
    setSaving(true);
    setSaveError(false);

    try {
      const profile: LearningProfile = {
        responseMode: state.responseMode ?? 'mixed',
        gradeLevel: state.gradeLevel ?? 6,
        accessibilitySettings: {
          readerFont: false,
          colorVision: 'standard',
          highContrast: false,
          largeText: false,
          focusMode: false,
          lowMotion: reduceMotion,
        },
      };

      await saveProfile(profile);
      await markFirstRunComplete();

      void trackOnboardingEvent({
        name: 'onboarding_completed',
        totalDurationMs: Date.now() - state.startTimestamp,
        mode: state.responseMode ?? 'mixed',
        grade: state.gradeLevel ?? 6,
      });

      router.replace('/(app)');
    } catch {
      // Show retry feedback — don't navigate away until profile is saved
      setSaving(false);
      setSaveError(true);
    }
  }, [saving, state, reduceMotion, router]);

  // ---------------------------------------------------------------------------
  // CTA button text per page
  // ---------------------------------------------------------------------------

  const getCTALabel = (): string | null => {
    switch (state.currentPage) {
      case 0: return 'Tara, kilalanin mo ako!';
      case 1: return 'Susunod →';
      case 2: return state.gradeLevel != null ? 'Susunod →' : null;
      case 3: return null; // Mode cards auto-advance
      case 4: return 'Susunod →';
      case 5: return saving ? 'Saving...' : 'Tara mag-aral! 🎉';
      default: return null;
    }
  };

  const handleCTAPress = () => {
    switch (state.currentPage) {
      case 0: goToPage(1); break;
      case 1: goToPage(2); break;
      case 2:
        if (state.gradeLevel != null) goToPage(3);
        break;
      case 4: handleDemoNext(); break;
      case 5: void handleComplete(); break;
    }
  };

  const ctaLabel = getCTALabel();

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------

  return (
    <View style={styles.container}>
      <PagerView
        ref={pagerRef}
        style={styles.pager}
        initialPage={0}
        scrollEnabled={canSwipeForward(state)}
        onPageSelected={handlePageSelected}
      >
        {/* Page 0: Welcome */}
        <View key="0" style={styles.page}>
          <WelcomeScreen onNext={() => goToPage(1)} reduceMotion={reduceMotion} />
        </View>

        {/* Page 1: Offline */}
        <View key="1" style={styles.page}>
          <OfflineScreen
            onNext={() => goToPage(2)}
            onSkip={() => goToPage(2)}
            reduceMotion={reduceMotion}
          />
        </View>

        {/* Page 2: Grade */}
        <View key="2" style={styles.page}>
          <GradeScreen
            selectedGrade={state.gradeLevel}
            onSelectGrade={handleGradeSelect}
            onNext={() => goToPage(3)}
            reduceMotion={reduceMotion}
          />
        </View>

        {/* Page 3: Mode */}
        <View key="3" style={styles.page}>
          <ModeScreen
            onSelectMode={handleModeSelect}
            onSkip={handleModeSkip}
            reduceMotion={reduceMotion}
          />
        </View>

        {/* Page 4: Demo */}
        <View key="4" style={styles.page}>
          <DemoScreen
            gradeLevel={state.gradeLevel ?? 6}
            responseMode={state.responseMode ?? 'mixed'}
            reduceMotion={reduceMotion}
            onNext={handleDemoNext}
            onTTSStatus={(played) => { ttsPlayedRef.current = played; }}
            onSVGStatus={(rendered) => { svgRenderedRef.current = rendered; }}
          />
        </View>

        {/* Page 5: Curriculum */}
        <View key="5" style={styles.page}>
          <CurriculumScreen onComplete={handleComplete} reduceMotion={reduceMotion} />
        </View>
      </PagerView>

      {/* Bottom controls */}
      <View style={styles.bottomBar}>
        <ProgressDots current={state.currentPage} />

        {ctaLabel && (
          <Pressable
            onPress={handleCTAPress}
            style={[styles.ctaButton, saving && styles.ctaDisabled]}
            disabled={saving}
            accessibilityRole="button"
          >
            <Text style={styles.ctaText}>{ctaLabel}</Text>
          </Pressable>
        )}

        {saveError && (
          <Text style={styles.errorText}>
            Hindi ko na-save. Subukan ulit? 🔄
          </Text>
        )}
      </View>
    </View>
  );
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Determine if forward swipe is allowed based on current state. */
function canSwipeForward(state: OnboardingState): boolean {
  // Page 2 (grade) requires selection before advancing
  if (state.currentPage === 2 && state.gradeLevel == null) return false;
  // Page 3 (mode) auto-advances on tap, but allow swipe back
  return true;
}

// ---------------------------------------------------------------------------
// Styles
// ---------------------------------------------------------------------------

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF9F2',
  },
  pager: {
    flex: 1,
  },
  page: {
    flex: 1,
    paddingBottom: 10,
  },
  bottomBar: {
    paddingHorizontal: 24,
    paddingBottom: 20,
    paddingTop: 6,
    alignItems: 'center',
    gap: 8,
  },
  ctaButton: {
    backgroundColor: '#F27A3A',
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 28,
    minWidth: 180,
    minHeight: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ctaDisabled: {
    opacity: 0.6,
  },
  ctaText: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '700',
  },
  errorText: {
    fontSize: 13,
    color: '#D4510A',
    textAlign: 'center',
  },
});

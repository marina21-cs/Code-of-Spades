/**
 * Suri fox mascot component.
 *
 * Renders a placeholder SVG fox with different poses. Designed to be swapped
 * with Lottie animations once final assets arrive. Respects reduce-motion
 * by skipping any animated transitions between poses.
 */
import { StyleSheet, View } from 'react-native';
import Svg, { Circle, Ellipse, Path, Polygon } from 'react-native-svg';

import { useReduceMotion } from '../useReduceMotion';

export type SuriPose =
  | 'wave'
  | 'confident'
  | 'curious'
  | 'thinking'
  | 'celebrating'
  | 'proud';

interface SuriMascotProps {
  pose: SuriPose;
  size?: 'small' | 'medium' | 'large';
}

const SIZE_MAP = {
  small: 80,
  medium: 140,
  large: 200,
} as const;

/**
 * Placeholder SVG fox mascot. Each pose varies subtle details (ear angle,
 * tail position, paw gesture). The base shape is consistent.
 */
export function SuriMascot({ pose, size = 'medium' }: SuriMascotProps) {
  const reduceMotion = useReduceMotion();
  const dimension = SIZE_MAP[size];

  return (
    <View
      style={[styles.container, { width: dimension, height: dimension }]}
      accessibilityLabel="Suri the fox mascot"
      accessibilityRole="image"
    >
      <Svg
        width={dimension}
        height={dimension}
        viewBox="0 0 100 100"
      >
        {/* Body */}
        <Ellipse cx={50} cy={65} rx={22} ry={25} fill="#F27A3A" />

        {/* Head */}
        <Circle cx={50} cy={35} r={18} fill="#F27A3A" />

        {/* Inner face */}
        <Ellipse cx={50} cy={40} rx={12} ry={10} fill="#FFF5E6" />

        {/* Eyes */}
        <Circle cx={44} cy={33} r={3} fill="#2D1B0E" />
        <Circle cx={56} cy={33} r={3} fill="#2D1B0E" />
        {/* Eye highlights */}
        <Circle cx={45} cy={32} r={1} fill="#FFF" />
        <Circle cx={57} cy={32} r={1} fill="#FFF" />

        {/* Nose */}
        <Ellipse cx={50} cy={38} rx={2.5} ry={2} fill="#2D1B0E" />

        {/* Mouth — varies by pose */}
        {pose === 'celebrating' || pose === 'wave' ? (
          <Path d="M46 41 Q50 45 54 41" stroke="#2D1B0E" strokeWidth={1.2} fill="none" />
        ) : (
          <Path d="M47 41 Q50 43 53 41" stroke="#2D1B0E" strokeWidth={1} fill="none" />
        )}

        {/* Ears */}
        <Polygon
          points={pose === 'curious' ? '35,22 40,8 48,22' : '35,24 42,10 48,24'}
          fill="#F27A3A"
        />
        <Polygon
          points={pose === 'curious' ? '52,22 60,8 65,22' : '52,24 58,10 65,24'}
          fill="#F27A3A"
        />
        {/* Inner ears */}
        <Polygon points="38,22 42,14 46,22" fill="#FFB88C" />
        <Polygon points="54,22 58,14 62,22" fill="#FFB88C" />

        {/* Tail */}
        <Path
          d={
            pose === 'celebrating'
              ? 'M72 60 Q85 45 78 35'
              : pose === 'confident'
                ? 'M72 62 Q88 55 80 45'
                : 'M72 65 Q85 60 80 50'
          }
          stroke="#F27A3A"
          strokeWidth={6}
          strokeLinecap="round"
          fill="none"
        />
        {/* Tail tip */}
        <Circle
          cx={pose === 'celebrating' ? 78 : 80}
          cy={pose === 'celebrating' ? 35 : pose === 'confident' ? 45 : 50}
          r={4}
          fill="#FFF5E6"
        />

        {/* Paws — wave pose raises one paw */}
        {pose === 'wave' ? (
          <>
            <Ellipse cx={38} cy={82} rx={5} ry={4} fill="#2D1B0E" />
            <Path d="M60 60 L68 52" stroke="#F27A3A" strokeWidth={5} strokeLinecap="round" />
            <Circle cx={69} cy={51} r={3.5} fill="#FFF5E6" />
          </>
        ) : pose === 'proud' ? (
          <>
            <Ellipse cx={38} cy={82} rx={5} ry={4} fill="#2D1B0E" />
            <Ellipse cx={62} cy={82} rx={5} ry={4} fill="#2D1B0E" />
          </>
        ) : (
          <>
            <Ellipse cx={38} cy={82} rx={5} ry={4} fill="#2D1B0E" />
            <Ellipse cx={62} cy={82} rx={5} ry={4} fill="#2D1B0E" />
          </>
        )}
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});

/**
 * Auditory mode demo response — text + TTS auto-play + audio wave indicator.
 * Falls back gracefully if TTS fails.
 */
import { useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { speak, stopSpeaking } from '@/voice/tts';

import type { OnboardingDemoResponse } from '../types';

interface DemoResponseAuditoryProps {
  content: OnboardingDemoResponse;
  reduceMotion: boolean;
  onTTSStatus?: (played: boolean) => void;
}

export function DemoResponseAuditory({
  content,
  reduceMotion,
  onTTSStatus,
}: DemoResponseAuditoryProps) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [ttsFailed, setTtsFailed] = useState(false);
  // Stabilize callback ref to avoid useEffect re-triggering on parent re-render
  const onTTSStatusRef = useRef(onTTSStatus);
  onTTSStatusRef.current = onTTSStatus;

  useEffect(() => {
    const textToSpeak = content.ttsText ?? content.responseText;

    const result = speak(textToSpeak, {
      onStart: () => {
        setIsSpeaking(true);
        onTTSStatusRef.current?.(true);
      },
      onDone: () => setIsSpeaking(false),
      onStopped: () => setIsSpeaking(false),
      onError: () => {
        setIsSpeaking(false);
        setTtsFailed(true);
        onTTSStatusRef.current?.(false);
      },
    });

    if (result === null) {
      setTtsFailed(true);
      onTTSStatusRef.current?.(false);
    }

    return () => {
      void stopSpeaking();
    };
  }, [content]);

  return (
    <View style={styles.container}>
      {/* Audio wave indicator */}
      {isSpeaking && !reduceMotion && (
        <View style={styles.audioWave} accessibilityLabel="Audio playing">
          <Text style={styles.waveEmoji}>🔊</Text>
          <View style={styles.waveBars}>
            {[1, 2, 3, 4, 5].map((i) => (
              <View key={i} style={[styles.bar, { height: 6 + i * 3 }]} />
            ))}
          </View>
        </View>
      )}

      {/* Text response (always shown) */}
      <Text style={styles.responseText}>{content.responseText}</Text>

      {/* TTS failure fallback */}
      {ttsFailed && (
        <Text style={styles.fallbackNote}>
          I-check ang TTS settings ng phone mo 🔇
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: 10,
  },
  audioWave: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 4,
  },
  waveEmoji: {
    fontSize: 18,
  },
  waveBars: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 3,
  },
  bar: {
    width: 4,
    backgroundColor: '#F27A3A',
    borderRadius: 2,
  },
  responseText: {
    fontSize: 14,
    color: '#4A3728',
    lineHeight: 22,
  },
  fallbackNote: {
    fontSize: 12,
    color: '#9A7A5A',
    fontStyle: 'italic',
    marginTop: 4,
  },
});

/**
 * 2×2 grid of learning mode cards for onboarding Screen 4.
 */
import { StyleSheet, View } from 'react-native';

import type { ResponseMode } from '../types';
import { ONBOARDING_MODE_OPTIONS } from '../types';
import { ModeCard } from './ModeCard';

interface ModeCardGridProps {
  onSelectMode: (mode: ResponseMode) => void;
}

export function ModeCardGrid({ onSelectMode }: ModeCardGridProps) {
  return (
    <View style={styles.grid}>
      {ONBOARDING_MODE_OPTIONS.map((option) => (
        <ModeCard
          key={option.mode}
          icon={option.icon}
          label={option.label}
          description={option.description}
          onPress={() => onSelectMode(option.mode)}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 16,
  },
});

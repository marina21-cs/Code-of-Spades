# Implementation Plan: Suri Onboarding — Feature Showcase + Learning Profile Setup

## Overview
Implement a 6-screen first-run onboarding flow using a single-file PagerView approach. One route (`app/onboarding.tsx`) contains a native pager that hosts all 6 screen components. State (grade, mode, page index) is managed locally via useReducer — no Context needed. Screen sub-components live in `src/onboarding/screens/` and are pure/stateless. The flow uses react-native-pager-view for native swipe, react-native-reanimated for animations, react-native-svg for visual mode diagrams, and persists via the existing profileStore.

## Tasks

- [ ] 1. Install dependencies and configure build tools #req-1 #req-8 #req-9
  - [ ] 1.1. Run `npx expo install react-native-gesture-handler react-native-reanimated react-native-svg react-native-pager-view lottie-react-native`
  - [ ] 1.2. Add `'react-native-reanimated/plugin'` to `babel.config.js` plugins array
  - [ ] 1.3. Wrap `<Slot />` in `app/_layout.tsx` with `<GestureHandlerRootView style={{flex:1}}>`
  - [ ] 1.4. Run `npx tsc --noEmit` to verify no type errors
- [ ] 2. Create onboarding types #req-1 #req-4 #req-5 #req-6
  - [ ] 2.1. Create `src/onboarding/types.ts` with OnboardingState, OnboardingAction, OnboardingDemoResponse, SvgDiagramSpec, SvgElement interfaces
  - [ ] 2.2. Define screen prop interfaces for each of the 6 screens
  - [ ] 2.3. Verify types compile cleanly
- [ ] 3. Create useReduceMotion hook #req-9
  - [ ] 3.1. Create `src/onboarding/useReduceMotion.ts`
  - [ ] 3.2. Use `AccessibilityInfo.isReduceMotionEnabled()` for initial value
  - [ ] 3.3. Subscribe to change events for live updates, clean up on unmount
  - [ ] 3.4. Default to `false` if API is unavailable
- [ ] 4. Create onboarding analytics module #req-11
  - [ ] 4.1. Create `src/onboarding/analytics.ts`
  - [ ] 4.2. Define OnboardingEvent discriminated union type
  - [ ] 4.3. Implement `ensureAnalyticsTable()` to create the sqlite table if not exists
  - [ ] 4.4. Implement `trackOnboardingEvent(event)` that inserts JSON-serialized properties
  - [ ] 4.5. Use the existing `getDB()` from `src/db/database` for the sqlite connection
- [ ] 5. Create bundled demo content — 28 pre-built responses #req-6
  - [ ] 5.1. Create `src/onboarding/demoContent.ts`
  - [ ] 5.2. Define demo entries for Grades 4-10 with visual, auditory, reading, and mixed variants
  - [ ] 5.3. Include SVG path data for visual/mixed modes (simple 5-10 element diagrams)
  - [ ] 5.4. Include TTS-ready Filipino text and textFallback for every SVG entry
  - [ ] 5.5. Export `getDemoContent(grade, mode)` lookup function
- [ ] 6. Create shared components — ProgressDots and SuriMascot #req-2 #req-3 #req-8 #req-9
  - [ ] 6.1. Create `src/onboarding/components/ProgressDots.tsx` (6 dots, current highlighted)
  - [ ] 6.2. Create `src/onboarding/components/SuriMascot.tsx` (pose prop, size prop, placeholder SVG fox)
  - [ ] 6.3. SuriMascot uses useReduceMotion to disable animations when active
  - [ ] 6.4. All components use StyleSheet, meet 48dp touch targets where interactive
- [ ] 7. Create GradeGrid and ModeCardGrid components #req-4 #req-5
  - [ ] 7.1. Create `src/onboarding/components/GradeGrid.tsx` (Grade 4-10, responsive grid, selected state with border + checkmark)
  - [ ] 7.2. Create `src/onboarding/components/ModeCard.tsx` (icon + Filipino label + description, min 64dp height)
  - [ ] 7.3. Create `src/onboarding/components/ModeCardGrid.tsx` (2x2 grid of ModeCards)
  - [ ] 7.4. Ensure all touch targets min 48dp, selected state not color-only
- [ ] 8. Create MockChat and DemoResponse components #req-6
  - [ ] 8.1. Create `src/onboarding/components/MockChat.tsx` (student bubble + Suri response bubble)
  - [ ] 8.2. Create `src/onboarding/components/DemoResponseVisual.tsx` (SVG from SvgDiagramSpec, error boundary with text fallback)
  - [ ] 8.3. Create `src/onboarding/components/DemoResponseAuditory.tsx` (text + TTS auto-play via existing speak(), audio wave animation, fallback on failure)
  - [ ] 8.4. Create `src/onboarding/components/DemoResponseReading.tsx` (structured bullet-point layout)
  - [ ] 8.5. Create `src/onboarding/components/DemoResponseMixed.tsx` (small SVG + 2-sentence text)
  - [ ] 8.6. All components expose onTTSStatus/onSVGStatus callbacks for analytics
- [ ] 9. Create DepEdBadge component #req-7
  - [ ] 9.1. Create `src/onboarding/components/DepEdBadge.tsx`
  - [ ] 9.2. Render DepEd-inspired seal using react-native-svg
  - [ ] 9.3. Animate checkmark reveal with react-native-reanimated, respect reduceMotion
  - [ ] 9.4. Mark as decorative for accessibility (importantForAccessibility="no")
- [ ] 10. Create screen sub-components (6 screens as stateless components) #req-2 #req-3 #req-4 #req-5 #req-6 #req-7
  - [ ] 10.1. Create `src/onboarding/screens/WelcomeScreen.tsx` — SuriMascot wave (large), copy, warm gradient
  - [ ] 10.2. Create `src/onboarding/screens/OfflineScreen.tsx` — signal bar animation, SuriMascot confident
  - [ ] 10.3. Create `src/onboarding/screens/GradeScreen.tsx` — SuriMascot curious, GradeGrid, Filipino copy
  - [ ] 10.4. Create `src/onboarding/screens/ModeScreen.tsx` — SuriMascot curious, ModeCardGrid, Filipino copy
  - [ ] 10.5. Create `src/onboarding/screens/DemoScreen.tsx` — reads grade+mode via props, renders MockChat with getDemoContent()
  - [ ] 10.6. Create `src/onboarding/screens/CurriculumScreen.tsx` — DepEdBadge, trust copy, Filipino text
- [ ] 11. Create the onboarding pager route (app/onboarding.tsx) #req-1 #req-8 #req-11 #req-12
  - [ ] 11.1. Create `app/onboarding.tsx` with useReducer for OnboardingState
  - [ ] 11.2. Render PagerView with 6 pages, each wrapping a screen sub-component
  - [ ] 11.3. Pass state + callbacks as props to each screen
  - [ ] 11.4. Render ProgressDots outside pager, synced to currentPage
  - [ ] 11.5. Render CTA buttons per page (Tara kilalanin mo ako, Susunod, etc.) — gated appropriately
  - [ ] 11.6. Gate forward swipe on Page 2 (grade required before advancing)
  - [ ] 11.7. Auto-advance on mode selection (Page 3 → Page 4)
  - [ ] 11.8. Reset mode when swiping back to Page 3
  - [ ] 11.9. Track all analytics events at appropriate page transitions
  - [ ] 11.10. On final CTA: build LearningProfile, saveProfile(), markFirstRunComplete(), navigate to /(app)
- [ ] 12. Create entry redirect and main app placeholder #req-1 #req-7
  - [ ] 12.1. Create `app/index.tsx` that calls isFirstRun() and redirects with router.replace()
  - [ ] 12.2. Create `app/(app)/_layout.tsx` minimal layout for main app
  - [ ] 12.3. Create `app/(app)/index.tsx` Chat tab placeholder with personalized Suri greeting from stored profile
  - [ ] 12.4. Verify full flow: first run → onboarding → chat; subsequent launches skip onboarding

## Task Dependency Graph

```json
{
  "waves": [
    [1],
    [2, 3, 4],
    [5, 6, 7, 9],
    [8, 10],
    [11],
    [12]
  ],
  "dependencies": {
    "1": [],
    "2": [1],
    "3": [1],
    "4": [1],
    "5": [2],
    "6": [2, 3],
    "7": [2],
    "8": [2, 3, 5],
    "9": [1, 3],
    "10": [6, 7, 8, 9],
    "11": [2, 3, 4, 6, 10],
    "12": [11]
  }
}
```

## Notes

- **Single-file pager approach**: `app/onboarding.tsx` uses `react-native-pager-view` for native swipe UX. State lives in the pager via useReducer — no Context needed since all screens are rendered as children of one component.
- **Screen components are pure**: Each `src/onboarding/screens/*.tsx` receives props and calls callbacks up. No internal state management, no hooks calling profileStore directly.
- **Suri mascot assets**: Using placeholder SVG fox illustrations until final Lottie animation files are provided by a designer. The `SuriMascot` component is structured to swap in Lottie seamlessly.
- **Demo content accuracy**: The 28 demo responses use actual DepEd MELC Science topics per grade level. Content should be reviewed by a curriculum specialist before release.
- **No test framework yet**: The project has no test runner configured. Testing is deferred to a follow-up.

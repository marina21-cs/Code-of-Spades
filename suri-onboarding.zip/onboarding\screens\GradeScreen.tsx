/**
 * Screen 3: Grade Level Picker — Suri asks the student's grade.
 */
import { StyleSheet, Text, View } from 'react-native';

import { GradeGrid } from '../components/GradeGrid';
import { SuriMascot } from '../components/SuriMascot';
import type { GradeScreenProps } from '../types';

export function GradeScreen({
  selectedGrade,
  onSelectGrade,
  reduceMotion,
}: GradeScreenProps) {
  return (
    <View style={styles.container}>
      <SuriMascot pose="curious" size="small" />

      <Text style={styles.question}>
        {'Para ma-match ko yung level mo —\nanong grade mo na?'}
      </Text>

      <GradeGrid selectedGrade={selectedGrade} onSelectGrade={onSelectGrade} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    gap: 24,
  },
  question: {
    fontSize: 17,
    fontWeight: '600',
    color: '#4A3728',
    textAlign: 'center',
    lineHeight: 25,
  },
});

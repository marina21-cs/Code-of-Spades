/**
 * Local onboarding analytics — writes events to expo-sqlite.
 *
 * All onboarding events are stored locally for potential future sync.
 * No network calls are made. The table is created lazily on first use
 * (the root layout guarantees initDB() has run before any route renders).
 */
import { getDB } from '@/db/database';

// ---------------------------------------------------------------------------
// Event Types
// ---------------------------------------------------------------------------

export type OnboardingEvent =
  | { name: 'onboarding_started'; timestamp: number }
  | { name: 'onboarding_offline_viewed'; timestamp: number }
  | { name: 'onboarding_grade_selected'; grade: number; timestamp: number }
  | { name: 'onboarding_mode_selected'; mode: string; wasSkip: boolean; timestamp: number }
  | {
      name: 'onboarding_demo_played';
      grade: number;
      mode: string;
      ttsPlayed: boolean;
      svgRendered: boolean;
    }
  | { name: 'onboarding_completed'; totalDurationMs: number; mode: string; grade: number };

// ---------------------------------------------------------------------------
// Table Setup
// ---------------------------------------------------------------------------

let tableCreated = false;

/**
 * Ensure the onboarding_events table exists. Idempotent — safe to call
 * multiple times. Uses a module-level flag to skip redundant SQL after
 * the first successful call.
 */
async function ensureAnalyticsTable(): Promise<void> {
  if (tableCreated) return;

  const db = getDB();
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS onboarding_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_name TEXT NOT NULL,
      properties TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  tableCreated = true;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Track an onboarding event. Writes to local sqlite — never makes network calls.
 * Fire-and-forget safe: errors are logged but don't crash the onboarding flow.
 */
export async function trackOnboardingEvent(event: OnboardingEvent): Promise<void> {
  try {
    await ensureAnalyticsTable();

    const db = getDB();
    const { name, ...properties } = event;

    await db.runAsync(
      'INSERT INTO onboarding_events (event_name, properties) VALUES (?, ?)',
      name,
      JSON.stringify(properties),
    );
  } catch (error) {
    // Analytics should never crash the onboarding. Log in dev, swallow in prod.
    if (__DEV__) {
      console.warn('[onboarding/analytics] Failed to track event:', event.name, error);
    }
  }
}

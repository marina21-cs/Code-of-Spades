/**
 * Screen 2: Works Offline — Suri's primary value proposition.
 * Shows signal bars dropping to zero while Suri stays active.
 */
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Rect } from 'react-native-svg';

import { SuriMascot } from '../components/SuriMascot';
import type { OfflineScreenProps } from '../types';

export function OfflineScreen({ reduceMotion }: OfflineScreenProps) {
  return (
    <View style={styles.container}>
      {/* Signal bars illustration (static — shows "no signal" state) */}
      <View style={styles.signalRow}>
        <SignalBarsOff />
        <SuriMascot pose="confident" size="medium" />
      </View>

      <Text style={styles.headline}>{'"Walang WiFi? Okay lang!"'}</Text>

      <Text style={styles.body}>
        {'Nag-iisip ako kahit walang signal.\nPwede mo akong kausapin\nkahit saan, kahit kailan.'}
      </Text>
    </View>
  );
}

/** Static signal bars in "off" state — crossed out / grayed. */
function SignalBarsOff() {
  return (
    <Svg width={48} height={48} viewBox="0 0 48 48">
      <Rect x={6} y={34} width={6} height={8} rx={2} fill="#CCC" />
      <Rect x={15} y={28} width={6} height={14} rx={2} fill="#CCC" />
      <Rect x={24} y={22} width={6} height={20} rx={2} fill="#CCC" />
      <Rect x={33} y={16} width={6} height={26} rx={2} fill="#CCC" />
      {/* X mark over signal */}
      <Rect x={4} y={22} width={38} height={2.5} rx={1} fill="#E74C3C" transform="rotate(45 23 23)" />
      <Rect x={4} y={22} width={38} height={2.5} rx={1} fill="#E74C3C" transform="rotate(-45 23 23)" />
    </Svg>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    gap: 20,
  },
  signalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  headline: {
    fontSize: 22,
    fontWeight: '700',
    color: '#4A3728',
    textAlign: 'center',
  },
  body: {
    fontSize: 15,
    color: '#6A5A4A',
    textAlign: 'center',
    lineHeight: 23,
  },
});

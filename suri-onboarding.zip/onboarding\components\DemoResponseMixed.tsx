/**
 * Mixed mode demo response — small SVG diagram + short text explanation.
 */
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Ellipse, Line, Path, Polygon, Rect, Text as SvgText } from 'react-native-svg';

import type { OnboardingDemoResponse, SvgElement } from '../types';

interface DemoResponseMixedProps {
  content: OnboardingDemoResponse;
  onSVGStatus?: (rendered: boolean) => void;
}

export function DemoResponseMixed({ content, onSVGStatus }: DemoResponseMixedProps) {
  const hasSvg = !!content.svgSpec;
  let svgRendered = false;

  return (
    <View style={styles.container}>
      {/* Small SVG diagram */}
      {hasSvg && content.svgSpec && (
        <View style={styles.svgContainer}>
          {(() => {
            try {
              svgRendered = true;
              onSVGStatus?.(true);
              return (
                <Svg viewBox={content.svgSpec.viewBox} style={styles.svg}>
                  {content.svgSpec.elements.map((el, i) => renderElement(el, i))}
                </Svg>
              );
            } catch {
              svgRendered = false;
              onSVGStatus?.(false);
              return (
                <Text style={styles.fallback}>
                  {content.textFallback ?? ''}
                </Text>
              );
            }
          })()}
        </View>
      )}

      {/* Text explanation */}
      <Text style={styles.text}>{content.responseText}</Text>
    </View>
  );
}

function renderElement(el: SvgElement, key: number) {
  const props = el.props;
  switch (el.type) {
    case 'circle': return <Circle key={key} {...props} />;
    case 'ellipse': return <Ellipse key={key} {...props} />;
    case 'rect': return <Rect key={key} {...props} />;
    case 'path': return <Path key={key} {...props} />;
    case 'line': return <Line key={key} {...props} />;
    case 'polygon': return <Polygon key={key} {...props} />;
    case 'text': return <SvgText key={key} {...props}>{el.children ?? ''}</SvgText>;
    default: return null;
  }
}

const styles = StyleSheet.create({
  container: {
    gap: 10,
  },
  svgContainer: {
    alignItems: 'center',
  },
  svg: {
    width: '100%',
    height: 90,
  },
  text: {
    fontSize: 14,
    color: '#4A3728',
    lineHeight: 20,
  },
  fallback: {
    fontSize: 12,
    color: '#7A6A5A',
    fontStyle: 'italic',
  },
});

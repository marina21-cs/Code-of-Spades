/**
 * Chat tab placeholder — the landing screen after onboarding.
 * Shows Suri's personalized greeting based on the student's saved profile.
 */
import { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { loadProfile } from '@/profile/profileStore';
import type { LearningProfile } from '@/profile/types';
import { DEFAULT_PROFILE } from '@/profile/types';

export default function ChatTab() {
  const [profile, setProfile] = useState<LearningProfile>(DEFAULT_PROFILE);

  useEffect(() => {
    void loadProfile().then(setProfile);
  }, []);

  const greeting = getGreeting(profile.gradeLevel);

  return (
    <View style={styles.container}>
      <Text style={styles.emoji}>🦊</Text>
      <Text style={styles.greeting}>{greeting}</Text>
      <Text style={styles.prompt}>
        Ano ang gusto mong pag-aralan ngayon?
      </Text>
      <View style={styles.placeholder}>
        <Text style={styles.placeholderText}>
          Chat interface coming soon...
        </Text>
      </View>
    </View>
  );
}

function getGreeting(grade: number): string {
  if (grade <= 5) {
    return 'Handa na ako! Tanong ka lang 🦊';
  }
  if (grade <= 7) {
    return 'Handa na ako! Ano ang ituturo ko sayo ngayon?';
  }
  return 'Handa na ako! Tara, mag-aral tayo.';
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    backgroundColor: '#FFF9F2',
    gap: 12,
  },
  emoji: {
    fontSize: 48,
  },
  greeting: {
    fontSize: 20,
    fontWeight: '600',
    color: '#4A3728',
    textAlign: 'center',
  },
  prompt: {
    fontSize: 15,
    color: '#6A5A4A',
    textAlign: 'center',
  },
  placeholder: {
    marginTop: 32,
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E8DDD0',
    borderStyle: 'dashed',
  },
  placeholderText: {
    fontSize: 13,
    color: '#9A7A5A',
  },
});

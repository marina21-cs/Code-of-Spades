/**
 * Visual mode demo response — renders an SVG diagram with text fallback.
 */
import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Ellipse, Line, Path, Polygon, Rect, Text as SvgText } from 'react-native-svg';

import type { OnboardingDemoResponse, SvgElement } from '../types';

interface DemoResponseVisualProps {
  content: OnboardingDemoResponse;
  onSVGStatus?: (rendered: boolean) => void;
}

export function DemoResponseVisual({ content, onSVGStatus }: DemoResponseVisualProps) {
  const [svgFailed, setSvgFailed] = useState(false);

  if (svgFailed || !content.svgSpec) {
    onSVGStatus?.(false);
    return (
      <View>
        <Text style={styles.text}>{content.textFallback ?? content.responseText}</Text>
      </View>
    );
  }

  try {
    const { viewBox, elements } = content.svgSpec;
    onSVGStatus?.(true);

    return (
      <View style={styles.container}>
        <Svg viewBox={viewBox} style={styles.svg}>
          {elements.map((el, i) => renderSvgElement(el, i))}
        </Svg>
        <Text style={styles.caption}>{content.responseText}</Text>
      </View>
    );
  } catch {
    setSvgFailed(true);
    onSVGStatus?.(false);
    return (
      <View>
        <Text style={styles.text}>{content.textFallback ?? content.responseText}</Text>
      </View>
    );
  }
}

function renderSvgElement(el: SvgElement, key: number) {
  const props = el.props;

  switch (el.type) {
    case 'circle':
      return <Circle key={key} {...props} />;
    case 'ellipse':
      return <Ellipse key={key} {...props} />;
    case 'rect':
      return <Rect key={key} {...props} />;
    case 'path':
      return <Path key={key} {...props} />;
    case 'line':
      return <Line key={key} {...props} />;
    case 'polygon':
      return <Polygon key={key} {...props} />;
    case 'text':
      return <SvgText key={key} {...props}>{el.children ?? ''}</SvgText>;
    default:
      return null;
  }
}

const styles = StyleSheet.create({
  container: {
    gap: 8,
  },
  svg: {
    width: '100%',
    height: 160,
  },
  caption: {
    fontSize: 13,
    color: '#4A3728',
    fontStyle: 'italic',
  },
  text: {
    fontSize: 14,
    color: '#4A3728',
    lineHeight: 20,
  },
});

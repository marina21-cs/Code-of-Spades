/**
 * Progress dots indicator for the onboarding pager.
 * Shows 6 dots with the current page highlighted.
 */
import { StyleSheet, View } from 'react-native';

import { ONBOARDING_PAGE_COUNT } from '../types';

interface ProgressDotsProps {
  current: number;
}

export function ProgressDots({ current }: ProgressDotsProps) {
  return (
    <View style={styles.container} accessibilityRole="progressbar">
      {Array.from({ length: ONBOARDING_PAGE_COUNT }, (_, i) => (
        <View
          key={i}
          style={[styles.dot, i === current && styles.dotActive]}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 16,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#D4C5B0',
  },
  dotActive: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#F27A3A',
  },
});

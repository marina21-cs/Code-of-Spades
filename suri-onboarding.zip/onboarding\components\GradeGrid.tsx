/**
 * Grade level picker grid (Grade 4–10).
 * Responsive layout with selected state showing border + checkmark.
 * All touch targets are min 48dp.
 */
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { ONBOARDING_GRADES } from '../types';

interface GradeGridProps {
  selectedGrade: number | null;
  onSelectGrade: (grade: number) => void;
}

export function GradeGrid({ selectedGrade, onSelectGrade }: GradeGridProps) {
  return (
    <View style={styles.grid}>
      {ONBOARDING_GRADES.map((grade) => {
        const isSelected = selectedGrade === grade;
        return (
          <Pressable
            key={grade}
            style={[styles.button, isSelected && styles.buttonSelected]}
            onPress={() => onSelectGrade(grade)}
            accessibilityRole="button"
            accessibilityState={{ selected: isSelected }}
            accessibilityLabel={`Grade ${grade}`}
          >
            <Text style={[styles.label, isSelected && styles.labelSelected]}>
              Grade {grade}
            </Text>
            {isSelected && <Text style={styles.checkmark}>✓</Text>}
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 12,
    paddingHorizontal: 16,
  },
  button: {
    minWidth: 100,
    minHeight: 48,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#E8DDD0',
    backgroundColor: '#FFF9F2',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 6,
  },
  buttonSelected: {
    borderColor: '#F27A3A',
    backgroundColor: '#FFF0E6',
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    color: '#4A3728',
  },
  labelSelected: {
    color: '#D4510A',
    fontWeight: '600',
  },
  checkmark: {
    fontSize: 16,
    color: '#F27A3A',
    fontWeight: '700',
  },
});

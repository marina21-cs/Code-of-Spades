/**
 * Entry redirect — checks first-run status and navigates accordingly.
 *
 * If onboarding hasn't been completed, redirects to /onboarding.
 * If completed, redirects to /(app) (main chat tab).
 */
import { useEffect } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';

import { isFirstRun } from '@/profile/profileStore';

export default function EntryRedirect() {
  const router = useRouter();

  useEffect(() => {
    (async () => {
      const firstRun = await isFirstRun();
      if (firstRun) {
        router.replace('/onboarding');
      } else {
        router.replace('/(app)');
      }
    })();
  }, [router]);

  // Brief loading state while checking secure store
  return (
    <View style={styles.container}>
      <ActivityIndicator size="small" color="#F27A3A" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF9F2',
  },
});

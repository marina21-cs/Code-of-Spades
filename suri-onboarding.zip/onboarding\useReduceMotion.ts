/**
 * Hook to detect OS-level reduce-motion accessibility setting.
 *
 * Returns `true` when the student's device has "Reduce motion" (iOS) or
 * "Remove animations" (Android) enabled. Subscribes reactively — if the
 * setting changes while the app is open, the value updates.
 *
 * Used by onboarding to replace Suri animations with static images and
 * screen transitions with simple crossfades.
 */
import { useEffect, useState } from 'react';
import { AccessibilityInfo } from 'react-native';

export function useReduceMotion(): boolean {
  const [reduceMotion, setReduceMotion] = useState(false);

  useEffect(() => {
    // Read initial value
    AccessibilityInfo.isReduceMotionEnabled()
      .then((enabled) => setReduceMotion(enabled))
      .catch(() => {
        // API unavailable — default to animations enabled
        setReduceMotion(false);
      });

    // Subscribe to live changes
    const subscription = AccessibilityInfo.addEventListener(
      'reduceMotionChanged',
      (enabled) => setReduceMotion(enabled),
    );

    return () => {
      subscription.remove();
    };
  }, []);

  return reduceMotion;
}

/**
 * Screen 1: Meet Suri — warm introduction with fox mascot.
 */
import { StyleSheet, Text, View } from 'react-native';

import { SuriMascot } from '../components/SuriMascot';
import type { WelcomeScreenProps } from '../types';

export function WelcomeScreen({ reduceMotion }: WelcomeScreenProps) {
  return (
    <View style={styles.container}>
      <SuriMascot pose="wave" size="large" />

      <Text style={styles.greeting}>{'"Kamusta! Ako si Suri 🦊"'}</Text>

      <Text style={styles.tagline}>
        {'Kasama mo ako sa pag-aaral —\nkahit walang internet.'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    gap: 20,
  },
  greeting: {
    fontSize: 24,
    fontWeight: '700',
    color: '#4A3728',
    textAlign: 'center',
  },
  tagline: {
    fontSize: 16,
    color: '#6A5A4A',
    textAlign: 'center',
    lineHeight: 24,
  },
});

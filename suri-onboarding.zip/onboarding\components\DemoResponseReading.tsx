/**
 * Reading mode demo response — structured bullet-point text layout.
 * Renders markdown-like formatting (bold headers, bullets) as styled Text.
 */
import { StyleSheet, Text, View } from 'react-native';

import type { OnboardingDemoResponse } from '../types';

interface DemoResponseReadingProps {
  content: OnboardingDemoResponse;
}

export function DemoResponseReading({ content }: DemoResponseReadingProps) {
  // Simple render — the responseText includes markdown-like formatting
  // We render it as plain text with line breaks preserved.
  // A full markdown renderer would be overkill for 7 hardcoded strings.
  const lines = content.responseText.split('\n');

  return (
    <View style={styles.container}>
      {lines.map((line, i) => {
        const trimmed = line.trim();
        if (!trimmed) return <View key={i} style={styles.spacer} />;

        const isBold = trimmed.startsWith('**') && trimmed.includes('**', 2);
        const isBullet = trimmed.startsWith('•') || trimmed.startsWith('→');
        const isSubBullet = line.startsWith('  ');

        return (
          <Text
            key={i}
            style={[
              styles.line,
              isBold && styles.bold,
              isBullet && styles.bullet,
              isSubBullet && styles.subBullet,
            ]}
          >
            {trimmed.replace(/\*\*/g, '')}
          </Text>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: 2,
  },
  line: {
    fontSize: 14,
    color: '#4A3728',
    lineHeight: 20,
  },
  bold: {
    fontWeight: '700',
    fontSize: 15,
    marginTop: 4,
  },
  bullet: {
    paddingLeft: 4,
  },
  subBullet: {
    paddingLeft: 16,
    fontSize: 13,
    color: '#6A5A4A',
  },
  spacer: {
    height: 6,
  },
});

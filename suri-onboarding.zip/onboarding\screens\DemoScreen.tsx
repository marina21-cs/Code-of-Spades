/**
 * Screen 5: Study Buddy Live Demo — shows grade × mode specific mock chat.
 */
import { StyleSheet, Text, View } from 'react-native';

import { MockChat } from '../components/MockChat';
import { SuriMascot } from '../components/SuriMascot';
import { getDemoContent } from '../demoContent';
import type { DemoScreenProps } from '../types';

export function DemoScreen({
  gradeLevel,
  responseMode,
  reduceMotion,
  onTTSStatus,
  onSVGStatus,
}: DemoScreenProps) {
  const content = getDemoContent(gradeLevel, responseMode);

  return (
    <View style={styles.container}>
      <SuriMascot pose="thinking" size="small" />

      <MockChat
        content={content}
        reduceMotion={reduceMotion}
        onTTSStatus={onTTSStatus}
        onSVGStatus={onSVGStatus}
      />

      <Text style={styles.footer}>
        {'Ganyan kausap mo ako palagi —\nparang kaklase mo lang! 🦊'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 12,
    gap: 12,
  },
  footer: {
    fontSize: 14,
    color: '#6A5A4A',
    textAlign: 'center',
    lineHeight: 21,
    marginTop: 'auto',
    paddingBottom: 8,
  },
});

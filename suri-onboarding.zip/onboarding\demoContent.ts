/**
 * Bundled demo content for onboarding Screen 5.
 *
 * 7 grades × 4 modes = 28 pre-built responses using actual DepEd MELC Science
 * topics. All content is static — no network calls, no AI inference.
 * Total bundle impact: <50KB.
 */
import type { OnboardingDemoResponse, ResponseMode } from './types';

// ---------------------------------------------------------------------------
// Demo Responses — Grade 1
// ---------------------------------------------------------------------------

const GRADE_1_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 1,
  mode: 'visual',
  question: 'Suri, ilan ang bahagi ng katawan ko?',
  responseText: 'Eto ang mga bahagi ng katawan mo!',
  textFallback: 'Ulo, kamay, paa, tiyan, tuhod — marami ang bahagi ng katawan natin!',
  svgSpec: {
    viewBox: '0 0 140 200',
    elements: [
      { type: 'circle', props: { cx: 70, cy: 30, r: 20, fill: '#FDBF60', stroke: '#333', strokeWidth: 1.5 } },
      { type: 'rect', props: { x: 55, y: 52, width: 30, height: 50, fill: '#5DADE2', rx: 5 } },
      { type: 'line', props: { x1: 55, y1: 65, x2: 30, y2: 90, stroke: '#FDBF60', strokeWidth: 6, strokeLinecap: 'round' } },
      { type: 'line', props: { x1: 85, y1: 65, x2: 110, y2: 90, stroke: '#FDBF60', strokeWidth: 6, strokeLinecap: 'round' } },
      { type: 'line', props: { x1: 60, y1: 102, x2: 55, y2: 150, stroke: '#FDBF60', strokeWidth: 6, strokeLinecap: 'round' } },
      { type: 'line', props: { x1: 80, y1: 102, x2: 85, y2: 150, stroke: '#FDBF60', strokeWidth: 6, strokeLinecap: 'round' } },
      { type: 'text', props: { x: 95, y: 30, fontSize: 9, fill: '#333' }, children: 'Ulo' },
      { type: 'text', props: { x: 112, y: 88, fontSize: 9, fill: '#333' }, children: 'Kamay' },
      { type: 'text', props: { x: 90, y: 80, fontSize: 9, fill: '#333' }, children: 'Tiyan' },
      { type: 'text', props: { x: 90, y: 150, fontSize: 9, fill: '#333' }, children: 'Paa' },
    ],
  },
};

const GRADE_1_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 1,
  mode: 'auditory',
  question: 'Suri, ilan ang bahagi ng katawan ko?',
  responseText: 'Ang katawan natin ay may maraming bahagi! May ulo, kamay, paa, tiyan, at tuhod.',
  ttsText:
    'Ang katawan natin ay may maraming bahagi. Tingnan mo! May ulo ka sa pinaka-taas. May dalawang kamay ka. May dalawang paa ka. May tiyan sa gitna. At may tuhod para maka-tiklop ang legs mo!',
};

const GRADE_1_READING: OnboardingDemoResponse = {
  gradeLevel: 1,
  mode: 'reading',
  question: 'Suri, ilan ang bahagi ng katawan ko?',
  responseText:
    '**Mga Bahagi ng Katawan**\n\n' +
    '• **Ulo** — nasa pinaka-taas\n' +
    '• **Kamay** — dalawa, kaliwa at kanan\n' +
    '• **Tiyan** — nasa gitna\n' +
    '• **Tuhod** — para maka-bend ang legs\n' +
    '• **Paa** — dalawa, para makalakad',
};

const GRADE_1_MIXED: OnboardingDemoResponse = {
  gradeLevel: 1,
  mode: 'mixed',
  question: 'Suri, ilan ang bahagi ng katawan ko?',
  responseText: 'Maraming bahagi ang katawan: ulo, kamay, tiyan, tuhod, at paa!',
  textFallback: 'Ulo, Kamay, Tiyan, Tuhod, Paa.',
  svgSpec: {
    viewBox: '0 0 100 140',
    elements: [
      { type: 'circle', props: { cx: 50, cy: 25, r: 14, fill: '#FDBF60' } },
      { type: 'rect', props: { x: 38, y: 40, width: 24, height: 35, fill: '#5DADE2', rx: 4 } },
      { type: 'line', props: { x1: 38, y1: 50, x2: 22, y2: 65, stroke: '#FDBF60', strokeWidth: 5, strokeLinecap: 'round' } },
      { type: 'line', props: { x1: 62, y1: 50, x2: 78, y2: 65, stroke: '#FDBF60', strokeWidth: 5, strokeLinecap: 'round' } },
      { type: 'line', props: { x1: 43, y1: 75, x2: 40, y2: 110, stroke: '#FDBF60', strokeWidth: 5, strokeLinecap: 'round' } },
      { type: 'line', props: { x1: 57, y1: 75, x2: 60, y2: 110, stroke: '#FDBF60', strokeWidth: 5, strokeLinecap: 'round' } },
    ],
  },
};

// ---------------------------------------------------------------------------
// Demo Responses — Grade 2
// ---------------------------------------------------------------------------

const GRADE_2_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 2,
  mode: 'visual',
  question: 'Suri, ano ang mga hayop na may buhok at walang buhok?',
  responseText: 'Tignan mo ang dalawang grupo ng hayop!',
  textFallback: 'May buhok (mammals): aso, pusa, daga. Walang buhok: isda, ibon, palaka.',
  svgSpec: {
    viewBox: '0 0 220 120',
    elements: [
      { type: 'rect', props: { x: 5, y: 10, width: 100, height: 100, fill: '#FFF3E0', rx: 8, stroke: '#FF9800', strokeWidth: 1.5 } },
      { type: 'text', props: { x: 20, y: 30, fontSize: 10, fontWeight: 'bold', fill: '#E65100' }, children: 'May Buhok' },
      { type: 'text', props: { x: 15, y: 50, fontSize: 10, fill: '#333' }, children: '🐶 Aso' },
      { type: 'text', props: { x: 15, y: 68, fontSize: 10, fill: '#333' }, children: '🐱 Pusa' },
      { type: 'text', props: { x: 15, y: 86, fontSize: 10, fill: '#333' }, children: '🐭 Daga' },
      { type: 'rect', props: { x: 115, y: 10, width: 100, height: 100, fill: '#E3F2FD', rx: 8, stroke: '#1976D2', strokeWidth: 1.5 } },
      { type: 'text', props: { x: 125, y: 30, fontSize: 10, fontWeight: 'bold', fill: '#0D47A1' }, children: 'Walang Buhok' },
      { type: 'text', props: { x: 125, y: 50, fontSize: 10, fill: '#333' }, children: '🐟 Isda' },
      { type: 'text', props: { x: 125, y: 68, fontSize: 10, fill: '#333' }, children: '🐦 Ibon' },
      { type: 'text', props: { x: 125, y: 86, fontSize: 10, fill: '#333' }, children: '🐸 Palaka' },
    ],
  },
};

const GRADE_2_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 2,
  mode: 'auditory',
  question: 'Suri, ano ang mga hayop na may buhok at walang buhok?',
  responseText: 'Ang mga hayop na may buhok ay tinatawag na mammals — tulad ng aso, pusa, at daga. Ang walang buhok ay isda, ibon, at palaka.',
  ttsText:
    'Ang mga hayop na may buhok ay tinatawag na mammals. Halimbawa: aso, pusa, at daga. Silang lahat ay may fur o buhok sa katawan. ' +
    'Ang mga hayop na walang buhok ay tulad ng isda na may kaliskis, ibon na may balahibo, at palaka na may makinis na balat.',
};

const GRADE_2_READING: OnboardingDemoResponse = {
  gradeLevel: 2,
  mode: 'reading',
  question: 'Suri, ano ang mga hayop na may buhok at walang buhok?',
  responseText:
    '**Hayop: May Buhok vs Walang Buhok**\n\n' +
    '• **May buhok (Mammals):**\n' +
    '  → Aso 🐶, Pusa 🐱, Daga 🐭\n' +
    '  → Sila ay nagpapasuso sa anak\n\n' +
    '• **Walang buhok:**\n' +
    '  → Isda 🐟 (may kaliskis)\n' +
    '  → Ibon 🐦 (may balahibo)\n' +
    '  → Palaka 🐸 (makinis na balat)',
};

const GRADE_2_MIXED: OnboardingDemoResponse = {
  gradeLevel: 2,
  mode: 'mixed',
  question: 'Suri, ano ang mga hayop na may buhok at walang buhok?',
  responseText: 'May buhok = mammals (aso, pusa). Walang buhok = isda, ibon, palaka.',
  textFallback: 'Mammals: aso, pusa, daga. Hindi mammals: isda, ibon, palaka.',
  svgSpec: {
    viewBox: '0 0 160 60',
    elements: [
      { type: 'rect', props: { x: 5, y: 5, width: 70, height: 50, fill: '#FFF3E0', rx: 6 } },
      { type: 'text', props: { x: 12, y: 22, fontSize: 8, fill: '#E65100' }, children: 'May Buhok' },
      { type: 'text', props: { x: 12, y: 40, fontSize: 9, fill: '#333' }, children: '🐶🐱🐭' },
      { type: 'rect', props: { x: 85, y: 5, width: 70, height: 50, fill: '#E3F2FD', rx: 6 } },
      { type: 'text', props: { x: 92, y: 22, fontSize: 8, fill: '#0D47A1' }, children: 'Wala' },
      { type: 'text', props: { x: 92, y: 40, fontSize: 9, fill: '#333' }, children: '🐟🐦🐸' },
    ],
  },
};


// ---------------------------------------------------------------------------
// Demo Responses — Grade 3
// ---------------------------------------------------------------------------

const GRADE_3_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 3,
  mode: 'visual',
  question: 'Suri, ano ang tatlong states of matter?',
  responseText: 'Eto ang solid, liquid, at gas!',
  textFallback: 'Solid = may hugis (yelo). Liquid = dumadaloy (tubig). Gas = kumakalat (steam).',
  svgSpec: {
    viewBox: '0 0 240 100',
    elements: [
      { type: 'rect', props: { x: 10, y: 30, width: 50, height: 50, fill: '#90CAF9', rx: 4, stroke: '#1565C0', strokeWidth: 1.5 } },
      { type: 'text', props: { x: 17, y: 90, fontSize: 9, fill: '#333' }, children: 'Solid (Yelo)' },
      { type: 'ellipse', props: { cx: 120, cy: 60, rx: 35, ry: 20, fill: '#81D4FA' } },
      { type: 'text', props: { x: 95, y: 90, fontSize: 9, fill: '#333' }, children: 'Liquid (Tubig)' },
      { type: 'circle', props: { cx: 200, cy: 40, r: 8, fill: '#B3E5FC', opacity: 0.6 } },
      { type: 'circle', props: { cx: 215, cy: 55, r: 6, fill: '#B3E5FC', opacity: 0.5 } },
      { type: 'circle', props: { cx: 195, cy: 60, r: 5, fill: '#B3E5FC', opacity: 0.4 } },
      { type: 'text', props: { x: 183, y: 90, fontSize: 9, fill: '#333' }, children: 'Gas (Steam)' },
    ],
  },
};

const GRADE_3_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 3,
  mode: 'auditory',
  question: 'Suri, ano ang tatlong states of matter?',
  responseText: 'May tatlong state ang matter: solid, liquid, at gas. Ang yelo ay solid, ang tubig ay liquid, at ang steam ay gas!',
  ttsText:
    'Ang lahat ng bagay sa paligid natin ay matter. May tatlong state ang matter. ' +
    'Una, solid. Ang solid ay may sariling hugis. Halimbawa: yelo, bato, mesa. ' +
    'Pangalawa, liquid. Ang liquid ay dumadaloy. Halimbawa: tubig, gatas, juice. ' +
    'Pangatlo, gas. Ang gas ay kumakalat sa lahat ng direksyon. Halimbawa: steam, hangin.',
};

const GRADE_3_READING: OnboardingDemoResponse = {
  gradeLevel: 3,
  mode: 'reading',
  question: 'Suri, ano ang tatlong states of matter?',
  responseText:
    '**Tatlong States of Matter**\n\n' +
    '• **Solid** — may sariling hugis\n' +
    '  → Halimbawa: yelo 🧊, bato, mesa\n\n' +
    '• **Liquid** — dumadaloy, sumusunod sa lalagyan\n' +
    '  → Halimbawa: tubig 💧, gatas, juice\n\n' +
    '• **Gas** — kumakalat, walang sariling hugis\n' +
    '  → Halimbawa: steam, hangin 💨',
};

const GRADE_3_MIXED: OnboardingDemoResponse = {
  gradeLevel: 3,
  mode: 'mixed',
  question: 'Suri, ano ang tatlong states of matter?',
  responseText: 'Solid = may hugis (yelo). Liquid = dumadaloy (tubig). Gas = kumakalat (steam).',
  textFallback: 'Solid: yelo. Liquid: tubig. Gas: steam.',
  svgSpec: {
    viewBox: '0 0 160 60',
    elements: [
      { type: 'rect', props: { x: 5, y: 10, width: 35, height: 35, fill: '#90CAF9', rx: 3 } },
      { type: 'text', props: { x: 8, y: 55, fontSize: 8, fill: '#333' }, children: 'Solid' },
      { type: 'ellipse', props: { cx: 80, cy: 28, rx: 25, ry: 14, fill: '#81D4FA' } },
      { type: 'text', props: { x: 65, y: 55, fontSize: 8, fill: '#333' }, children: 'Liquid' },
      { type: 'circle', props: { cx: 135, cy: 22, r: 5, fill: '#B3E5FC', opacity: 0.5 } },
      { type: 'circle', props: { cx: 145, cy: 32, r: 4, fill: '#B3E5FC', opacity: 0.4 } },
      { type: 'text', props: { x: 125, y: 55, fontSize: 8, fill: '#333' }, children: 'Gas' },
    ],
  },
};

const GRADE_4_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 4,
  mode: 'visual',
  question: 'Suri, ano ang mga bahagi ng halaman?',
  responseText: 'Ganito ang mga bahagi ng halaman!',
  textFallback:
    'Ang halaman ay may ugat (roots), tangkay (stem), dahon (leaves), at bulaklak (flower).',
  svgSpec: {
    viewBox: '0 0 200 280',
    elements: [
      // Roots
      { type: 'path', props: { d: 'M100 240 Q80 260 70 270', stroke: '#8B4513', strokeWidth: 2, fill: 'none' } },
      { type: 'path', props: { d: 'M100 240 Q110 255 120 270', stroke: '#8B4513', strokeWidth: 2, fill: 'none' } },
      { type: 'path', props: { d: 'M100 240 Q95 260 90 275', stroke: '#8B4513', strokeWidth: 1.5, fill: 'none' } },
      // Stem
      { type: 'rect', props: { x: 96, y: 100, width: 8, height: 140, fill: '#228B22', rx: 3 } },
      // Leaves
      { type: 'ellipse', props: { cx: 75, cy: 150, rx: 25, ry: 12, fill: '#32CD32', transform: 'rotate(-20 75 150)' } },
      { type: 'ellipse', props: { cx: 130, cy: 160, rx: 25, ry: 12, fill: '#32CD32', transform: 'rotate(15 130 160)' } },
      // Flower
      { type: 'circle', props: { cx: 100, cy: 85, r: 8, fill: '#FFD700' } },
      { type: 'circle', props: { cx: 90, cy: 75, r: 10, fill: '#FF69B4' } },
      { type: 'circle', props: { cx: 110, cy: 75, r: 10, fill: '#FF69B4' } },
      { type: 'circle', props: { cx: 95, cy: 65, r: 10, fill: '#FF69B4' } },
      { type: 'circle', props: { cx: 105, cy: 65, r: 10, fill: '#FF69B4' } },
      // Labels
      { type: 'text', props: { x: 40, y: 275, fontSize: 11, fill: '#333' }, children: 'Ugat' },
      { type: 'text', props: { x: 110, y: 200, fontSize: 11, fill: '#333' }, children: 'Tangkay' },
      { type: 'text', props: { x: 135, y: 155, fontSize: 11, fill: '#333' }, children: 'Dahon' },
      { type: 'text', props: { x: 115, y: 60, fontSize: 11, fill: '#333' }, children: 'Bulaklak' },
    ],
  },
};

const GRADE_4_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 4,
  mode: 'auditory',
  question: 'Suri, ano ang mga bahagi ng halaman?',
  responseText:
    'Ang halaman ay may apat na pangunahing bahagi: ugat, tangkay, dahon, at bulaklak. ' +
    'Ang ugat ang kumukuha ng tubig mula sa lupa. Ang tangkay ang nagdadala ng tubig pataas. ' +
    'Ang dahon ang gumagawa ng pagkain gamit ang sikat ng araw. At ang bulaklak ang tumutulong para magkaroon ng bagong halaman!',
  ttsText:
    'Ang halaman ay may apat na pangunahing bahagi. Una, ang ugat, ang kumukuha ng tubig mula sa lupa. ' +
    'Pangalawa, ang tangkay, ang nagdadala ng tubig pataas sa halaman. ' +
    'Pangatlo, ang dahon, ang gumagawa ng pagkain gamit ang sikat ng araw. ' +
    'At panghuli, ang bulaklak, ang tumutulong para magkaroon ng bagong halaman.',
};

const GRADE_4_READING: OnboardingDemoResponse = {
  gradeLevel: 4,
  mode: 'reading',
  question: 'Suri, ano ang mga bahagi ng halaman?',
  responseText:
    '**Mga Bahagi ng Halaman**\n\n' +
    '• **Ugat (Roots)** — kumukuha ng tubig at nutrients mula sa lupa\n' +
    '• **Tangkay (Stem)** — nagdadala ng tubig pataas sa buong halaman\n' +
    '• **Dahon (Leaves)** — gumagawa ng pagkain gamit ang sikat ng araw ☀️\n' +
    '• **Bulaklak (Flower)** — tumutulong sa pagpaparami ng halaman 🌸',
};

const GRADE_4_MIXED: OnboardingDemoResponse = {
  gradeLevel: 4,
  mode: 'mixed',
  question: 'Suri, ano ang mga bahagi ng halaman?',
  responseText:
    'Ang halaman ay may apat na bahagi: ugat (kumukuha ng tubig), tangkay (nagdadala pataas), ' +
    'dahon (gumagawa ng pagkain), at bulaklak (para sa pagpaparami).',
  textFallback:
    'Ugat = tubig, Tangkay = dala pataas, Dahon = gawa pagkain, Bulaklak = parami.',
  svgSpec: {
    viewBox: '0 0 180 140',
    elements: [
      { type: 'rect', props: { x: 86, y: 40, width: 8, height: 80, fill: '#228B22', rx: 3 } },
      { type: 'ellipse', props: { cx: 70, cy: 70, rx: 20, ry: 10, fill: '#32CD32' } },
      { type: 'ellipse', props: { cx: 115, cy: 80, rx: 20, ry: 10, fill: '#32CD32' } },
      { type: 'circle', props: { cx: 90, cy: 30, r: 12, fill: '#FF69B4' } },
      { type: 'path', props: { d: 'M90 120 Q75 135 65 140', stroke: '#8B4513', strokeWidth: 2, fill: 'none' } },
      { type: 'path', props: { d: 'M90 120 Q105 135 115 140', stroke: '#8B4513', strokeWidth: 2, fill: 'none' } },
    ],
  },
};

// ---------------------------------------------------------------------------
// Demo Responses — Grade 5
// ---------------------------------------------------------------------------

const GRADE_5_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 5,
  mode: 'visual',
  question: 'Suri, paano gumagalaw ang Earth?',
  responseText: 'Eto ang movement ng Earth!',
  textFallback:
    'Ang Earth ay umiikot sa sarili nito (rotation = araw at gabi) at umiikot din sa paligid ng Sun (revolution = seasons).',
  svgSpec: {
    viewBox: '0 0 240 180',
    elements: [
      // Sun
      { type: 'circle', props: { cx: 120, cy: 90, r: 25, fill: '#FFD700' } },
      { type: 'text', props: { x: 110, y: 95, fontSize: 11, fill: '#333' }, children: 'Sun' },
      // Orbit path
      { type: 'ellipse', props: { cx: 120, cy: 90, rx: 85, ry: 60, fill: 'none', stroke: '#999', strokeWidth: 1, strokeDasharray: '4 4' } },
      // Earth
      { type: 'circle', props: { cx: 205, cy: 90, r: 12, fill: '#4169E1' } },
      { type: 'text', props: { x: 193, y: 115, fontSize: 10, fill: '#333' }, children: 'Earth' },
      // Rotation arrow
      { type: 'path', props: { d: 'M200 80 A8 8 0 1 1 210 85', stroke: '#FF6347', strokeWidth: 1.5, fill: 'none' } },
      { type: 'text', props: { x: 175, y: 75, fontSize: 9, fill: '#FF6347' }, children: 'Rotation' },
      // Revolution arrow
      { type: 'path', props: { d: 'M160 35 L170 30 L165 42', fill: '#4682B4' } },
      { type: 'text', props: { x: 140, y: 25, fontSize: 9, fill: '#4682B4' }, children: 'Revolution' },
    ],
  },
};

const GRADE_5_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 5,
  mode: 'auditory',
  question: 'Suri, paano gumagalaw ang Earth?',
  responseText:
    'Ang Earth ay may dalawang uri ng galaw. Una, ang rotation — umiikot siya sa sarili niya, ' +
    'at dahil dito, nagkakaroon ng araw at gabi. Pangalawa, ang revolution — umiikot siya sa paligid ng Sun, ' +
    'at dahil dito, nagkakaroon ng mga seasons!',
  ttsText:
    'Ang Earth ay may dalawang uri ng galaw. Una, ang rotation. Umiikot siya sa sarili niya, ' +
    'kaya nagkakaroon ng araw at gabi. Isang buong ikot ay tumatagal ng 24 oras. ' +
    'Pangalawa, ang revolution. Umiikot siya sa paligid ng Sun, kaya nagkakaroon ng mga seasons. ' +
    'Isang buong ikot sa Sun ay tumatagal ng 365 days, o isang taon.',
};

const GRADE_5_READING: OnboardingDemoResponse = {
  gradeLevel: 5,
  mode: 'reading',
  question: 'Suri, paano gumagalaw ang Earth?',
  responseText:
    '**Mga Galaw ng Earth**\n\n' +
    '• **Rotation** — pag-ikot ng Earth sa sarili nito\n' +
    '  → Nagdudulot ng araw at gabi\n' +
    '  → 1 rotation = 24 oras\n\n' +
    '• **Revolution** — pag-ikot ng Earth sa paligid ng Sun\n' +
    '  → Nagdudulot ng apat na seasons\n' +
    '  → 1 revolution = 365 araw (1 taon)',
};

const GRADE_5_MIXED: OnboardingDemoResponse = {
  gradeLevel: 5,
  mode: 'mixed',
  question: 'Suri, paano gumagalaw ang Earth?',
  responseText:
    'Rotation = ikot sa sarili (araw/gabi, 24 hrs). Revolution = ikot sa Sun (seasons, 365 days).',
  textFallback: 'Rotation = 24 hrs, araw/gabi. Revolution = 365 days, seasons.',
  svgSpec: {
    viewBox: '0 0 180 120',
    elements: [
      { type: 'circle', props: { cx: 90, cy: 60, r: 18, fill: '#FFD700' } },
      { type: 'ellipse', props: { cx: 90, cy: 60, rx: 65, ry: 40, fill: 'none', stroke: '#999', strokeWidth: 1, strokeDasharray: '3 3' } },
      { type: 'circle', props: { cx: 155, cy: 60, r: 9, fill: '#4169E1' } },
    ],
  },
};

// ---------------------------------------------------------------------------
// Demo Responses — Grade 6
// ---------------------------------------------------------------------------

const GRADE_6_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 6,
  mode: 'visual',
  question: 'Suri, ano ang photosynthesis?',
  responseText: 'Ganito ginagawa ng halaman ang pagkain niya!',
  textFallback:
    'Photosynthesis: Sunlight + H₂O + CO₂ → Glucose (pagkain) + O₂ (oxygen). Nangyayari sa dahon (chloroplast).',
  svgSpec: {
    viewBox: '0 0 260 180',
    elements: [
      // Leaf shape
      { type: 'ellipse', props: { cx: 130, cy: 100, rx: 70, ry: 40, fill: '#90EE90', stroke: '#228B22', strokeWidth: 2 } },
      // Sun
      { type: 'circle', props: { cx: 50, cy: 35, r: 18, fill: '#FFD700' } },
      { type: 'text', props: { x: 35, y: 40, fontSize: 10, fill: '#333' }, children: 'Sikat ng Araw' },
      // Arrow from sun to leaf
      { type: 'path', props: { d: 'M65 50 L100 80', stroke: '#FFA500', strokeWidth: 2, fill: 'none' } },
      // Water arrow
      { type: 'text', props: { x: 80, y: 160, fontSize: 10, fill: '#4169E1' }, children: 'H₂O 💧' },
      { type: 'path', props: { d: 'M95 150 L110 125', stroke: '#4169E1', strokeWidth: 2, fill: 'none' } },
      // CO2 arrow
      { type: 'text', props: { x: 170, y: 160, fontSize: 10, fill: '#666' }, children: 'CO₂' },
      { type: 'path', props: { d: 'M180 150 L160 125', stroke: '#666', strokeWidth: 2, fill: 'none' } },
      // Output: Glucose
      { type: 'text', props: { x: 180, y: 50, fontSize: 10, fill: '#8B4513' }, children: 'Glucose 🍬' },
      { type: 'path', props: { d: 'M160 80 L185 55', stroke: '#8B4513', strokeWidth: 2, fill: 'none' } },
      // Output: Oxygen
      { type: 'text', props: { x: 195, y: 100, fontSize: 10, fill: '#228B22' }, children: 'O₂' },
      { type: 'path', props: { d: 'M175 100 L195 100', stroke: '#228B22', strokeWidth: 2, fill: 'none' } },
      // Center label
      { type: 'text', props: { x: 95, y: 105, fontSize: 11, fontWeight: 'bold', fill: '#006400' }, children: 'Photosynthesis' },
    ],
  },
};

const GRADE_6_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 6,
  mode: 'auditory',
  question: 'Suri, ano ang photosynthesis?',
  responseText:
    'Ang photosynthesis ay ang proseso kung paano gumagawa ng pagkain ang halaman gamit ang sikat ng araw, tubig, at carbon dioxide. ' +
    'Ang ginagawa niya, kino-convert niya ang light energy into food energy!',
  ttsText:
    'Ang photosynthesis ay ang proseso kung paano gumagawa ng pagkain ang halaman. ' +
    'Kailangan niya ng tatlong bagay: sikat ng araw, tubig, at carbon dioxide. ' +
    'Kapag pinagsama-sama niya ang mga ito sa loob ng dahon, sa chloroplast, ' +
    'gumagawa siya ng glucose, na pagkain ng halaman, at oxygen, na kailangan nating huminga.',
};

const GRADE_6_READING: OnboardingDemoResponse = {
  gradeLevel: 6,
  mode: 'reading',
  question: 'Suri, ano ang photosynthesis?',
  responseText:
    '**Photosynthesis**\n\n' +
    '• Proseso ng halaman para gumawa ng pagkain\n' +
    '• Kailangan: sikat ng araw ☀️ + tubig 💧 + carbon dioxide\n' +
    '• Resulta: glucose (pagkain) + oxygen\n' +
    '• Nangyayari sa leaves (sa chloroplast)\n\n' +
    '**Formula:** 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂',
};

const GRADE_6_MIXED: OnboardingDemoResponse = {
  gradeLevel: 6,
  mode: 'mixed',
  question: 'Suri, ano ang photosynthesis?',
  responseText:
    'Ginagawa ng halaman ang pagkain niya sa dahon — gamit ang sikat ng araw, tubig, at CO₂. Ang resulta: glucose at oxygen.',
  textFallback: 'Sunlight + Water + CO₂ → Glucose + Oxygen. Sa dahon nangyayari ito.',
  svgSpec: {
    viewBox: '0 0 180 100',
    elements: [
      { type: 'ellipse', props: { cx: 90, cy: 50, rx: 50, ry: 28, fill: '#90EE90', stroke: '#228B22', strokeWidth: 1.5 } },
      { type: 'circle', props: { cx: 30, cy: 20, r: 12, fill: '#FFD700' } },
      { type: 'path', props: { d: 'M42 28 L60 40', stroke: '#FFA500', strokeWidth: 1.5, fill: 'none' } },
      { type: 'text', props: { x: 70, y: 55, fontSize: 9, fill: '#006400' }, children: 'Photosynthesis' },
    ],
  },
};

// ---------------------------------------------------------------------------
// Demo Responses — Grade 7
// ---------------------------------------------------------------------------

const GRADE_7_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 7,
  mode: 'visual',
  question: 'Suri, ano ang atom?',
  responseText: 'Eto ang pinaka-basic na building block ng lahat ng bagay!',
  textFallback:
    'Ang atom ay may nucleus (protons + neutrons) sa gitna at electrons na umiiikot sa paligid (electron cloud).',
  svgSpec: {
    viewBox: '0 0 200 200',
    elements: [
      // Electron orbits
      { type: 'ellipse', props: { cx: 100, cy: 100, rx: 80, ry: 35, fill: 'none', stroke: '#87CEEB', strokeWidth: 1 } },
      { type: 'ellipse', props: { cx: 100, cy: 100, rx: 35, ry: 80, fill: 'none', stroke: '#87CEEB', strokeWidth: 1 } },
      { type: 'ellipse', props: { cx: 100, cy: 100, rx: 60, ry: 60, fill: 'none', stroke: '#87CEEB', strokeWidth: 1, transform: 'rotate(45 100 100)' } },
      // Nucleus
      { type: 'circle', props: { cx: 100, cy: 100, r: 18, fill: '#FF6347' } },
      { type: 'text', props: { x: 82, y: 105, fontSize: 9, fill: '#fff' }, children: 'Nucleus' },
      // Electrons
      { type: 'circle', props: { cx: 180, cy: 100, r: 5, fill: '#4169E1' } },
      { type: 'circle', props: { cx: 100, cy: 20, r: 5, fill: '#4169E1' } },
      { type: 'circle', props: { cx: 45, cy: 145, r: 5, fill: '#4169E1' } },
      // Labels
      { type: 'text', props: { x: 70, y: 195, fontSize: 10, fill: '#333' }, children: 'Proton (+) Neutron (0)' },
      { type: 'text', props: { x: 150, y: 80, fontSize: 10, fill: '#4169E1' }, children: 'Electron (-)' },
    ],
  },
};

const GRADE_7_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 7,
  mode: 'auditory',
  question: 'Suri, ano ang atom?',
  responseText:
    'Ang atom ang pinaka-maliit na building block ng lahat ng matter. ' +
    'May nucleus siya sa gitna na may protons at neutrons, at may electrons na umiiikot sa paligid.',
  ttsText:
    'Ang atom ang pinaka-maliit na unit ng matter. Lahat ng bagay sa mundo, gawa sa atoms. ' +
    'Sa gitna ng atom, may nucleus. Ang nucleus ay gawa sa protons, na positive ang charge, at neutrons, na walang charge. ' +
    'Sa paligid ng nucleus, may electrons na umiiikot. Ang electrons ay negative ang charge. ' +
    'Kapag pantay ang bilang ng protons at electrons, neutral ang atom.',
};

const GRADE_7_READING: OnboardingDemoResponse = {
  gradeLevel: 7,
  mode: 'reading',
  question: 'Suri, ano ang atom?',
  responseText:
    '**Atom — Building Block ng Matter**\n\n' +
    '• Pinaka-maliit na unit na may properties pa rin ng element\n' +
    '• **Nucleus** (gitna):\n' +
    '  → Protons (+) — positive charge\n' +
    '  → Neutrons (0) — walang charge\n' +
    '• **Electrons** (paligid):\n' +
    '  → Negative charge (-)\n' +
    '  → Umiiikot sa electron cloud\n' +
    '• Kapag equal protons at electrons → neutral atom',
};

const GRADE_7_MIXED: OnboardingDemoResponse = {
  gradeLevel: 7,
  mode: 'mixed',
  question: 'Suri, ano ang atom?',
  responseText:
    'Atom = nucleus (protons + neutrons) sa gitna, electrons umiiikot sa paligid. Lahat ng matter gawa sa atoms.',
  textFallback: 'Nucleus: protons(+) + neutrons(0). Electrons(-) sa paligid.',
  svgSpec: {
    viewBox: '0 0 140 140',
    elements: [
      { type: 'circle', props: { cx: 70, cy: 70, r: 12, fill: '#FF6347' } },
      { type: 'ellipse', props: { cx: 70, cy: 70, rx: 50, ry: 22, fill: 'none', stroke: '#87CEEB', strokeWidth: 1 } },
      { type: 'circle', props: { cx: 120, cy: 70, r: 4, fill: '#4169E1' } },
      { type: 'circle', props: { cx: 70, cy: 48, r: 4, fill: '#4169E1' } },
    ],
  },
};

// ---------------------------------------------------------------------------
// Demo Responses — Grade 8
// ---------------------------------------------------------------------------

const GRADE_8_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 8,
  mode: 'visual',
  question: 'Suri, paano gumagana ang ecosystem?',
  responseText: 'Eto ang food chain sa isang ecosystem!',
  textFallback:
    'Ecosystem food chain: Sun → Plants (producer) → Herbivore → Carnivore → Decomposer → nutrients balik sa lupa.',
  svgSpec: {
    viewBox: '0 0 280 120',
    elements: [
      { type: 'circle', props: { cx: 30, cy: 60, r: 15, fill: '#FFD700' } },
      { type: 'text', props: { x: 20, y: 90, fontSize: 9, fill: '#333' }, children: 'Sun' },
      { type: 'path', props: { d: 'M48 60 L70 60', stroke: '#333', strokeWidth: 1.5, fill: 'none' } },
      { type: 'rect', props: { x: 72, y: 48, width: 30, height: 24, fill: '#32CD32', rx: 4 } },
      { type: 'text', props: { x: 72, y: 90, fontSize: 8, fill: '#333' }, children: 'Producer' },
      { type: 'path', props: { d: 'M105 60 L125 60', stroke: '#333', strokeWidth: 1.5, fill: 'none' } },
      { type: 'rect', props: { x: 127, y: 48, width: 30, height: 24, fill: '#87CEEB', rx: 4 } },
      { type: 'text', props: { x: 125, y: 90, fontSize: 8, fill: '#333' }, children: 'Herbivore' },
      { type: 'path', props: { d: 'M160 60 L180 60', stroke: '#333', strokeWidth: 1.5, fill: 'none' } },
      { type: 'rect', props: { x: 182, y: 48, width: 30, height: 24, fill: '#FF6347', rx: 4 } },
      { type: 'text', props: { x: 180, y: 90, fontSize: 8, fill: '#333' }, children: 'Carnivore' },
      { type: 'path', props: { d: 'M215 60 L235 60', stroke: '#333', strokeWidth: 1.5, fill: 'none' } },
      { type: 'rect', props: { x: 237, y: 48, width: 35, height: 24, fill: '#8B4513', rx: 4 } },
      { type: 'text', props: { x: 233, y: 90, fontSize: 8, fill: '#333' }, children: 'Decomposer' },
    ],
  },
};

const GRADE_8_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 8,
  mode: 'auditory',
  question: 'Suri, paano gumagana ang ecosystem?',
  responseText:
    'Ang ecosystem ay isang community ng mga living things at ang kanilang environment na magkakakonekta through food chains at food webs.',
  ttsText:
    'Ang ecosystem ay isang community ng mga living things na nagtutu-interact sa isa\'t isa at sa kanilang environment. ' +
    'Ang energy ay nag-iistart sa Sun, na ginagamit ng plants para mag-photosynthesis. Sila ang producers. ' +
    'Kinakain sila ng herbivores, na kinakain naman ng carnivores. ' +
    'Kapag namatay ang organisms, ang decomposers ang nag-break down sa kanila, na nagbabalik ng nutrients sa lupa. ' +
    'Kaya isa itong cycle — walang nasasayang.',
};

const GRADE_8_READING: OnboardingDemoResponse = {
  gradeLevel: 8,
  mode: 'reading',
  question: 'Suri, paano gumagana ang ecosystem?',
  responseText:
    '**Ecosystem — Koneksyon ng Lahat ng Living Things**\n\n' +
    '• **Producers** (halaman) — gumagawa ng sariling pagkain via photosynthesis\n' +
    '• **Primary Consumers** (herbivores) — kumakain ng plants\n' +
    '• **Secondary Consumers** (carnivores) — kumakain ng herbivores\n' +
    '• **Decomposers** (fungi, bacteria) — bini-break down ang patay na organisms\n\n' +
    '**Energy flow:** Sun → Producer → Consumer → Decomposer → Nutrients → cycle ulit',
};

const GRADE_8_MIXED: OnboardingDemoResponse = {
  gradeLevel: 8,
  mode: 'mixed',
  question: 'Suri, paano gumagana ang ecosystem?',
  responseText:
    'Ang ecosystem ay cycle: Sun → Plants → Herbivores → Carnivores → Decomposers → nutrients balik sa lupa.',
  textFallback: 'Food chain: Sun → Producer → Herbivore → Carnivore → Decomposer → cycle.',
  svgSpec: {
    viewBox: '0 0 160 80',
    elements: [
      { type: 'circle', props: { cx: 20, cy: 40, r: 10, fill: '#FFD700' } },
      { type: 'path', props: { d: 'M33 40 L50 40', stroke: '#333', strokeWidth: 1, fill: 'none' } },
      { type: 'rect', props: { x: 52, y: 32, width: 20, height: 16, fill: '#32CD32', rx: 3 } },
      { type: 'path', props: { d: 'M74 40 L88 40', stroke: '#333', strokeWidth: 1, fill: 'none' } },
      { type: 'rect', props: { x: 90, y: 32, width: 20, height: 16, fill: '#87CEEB', rx: 3 } },
      { type: 'path', props: { d: 'M112 40 L126 40', stroke: '#333', strokeWidth: 1, fill: 'none' } },
      { type: 'rect', props: { x: 128, y: 32, width: 20, height: 16, fill: '#FF6347', rx: 3 } },
    ],
  },
};

// ---------------------------------------------------------------------------
// Demo Responses — Grade 9
// ---------------------------------------------------------------------------

const GRADE_9_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 9,
  mode: 'visual',
  question: 'Suri, ano ang heredity?',
  responseText: 'Eto kung paano naipapasa ang traits mula sa parents!',
  textFallback:
    'Heredity: Parents → DNA (genes) → Offspring. Dominant traits (AA, Aa) ay lumalabas. Recessive (aa) nakatago kung may dominant.',
  svgSpec: {
    viewBox: '0 0 220 160',
    elements: [
      // Parent 1
      { type: 'circle', props: { cx: 60, cy: 30, r: 18, fill: '#DDA0DD' } },
      { type: 'text', props: { x: 50, y: 35, fontSize: 10, fill: '#333' }, children: 'Aa' },
      { type: 'text', props: { x: 40, y: 60, fontSize: 9, fill: '#666' }, children: 'Mother' },
      // Parent 2
      { type: 'circle', props: { cx: 160, cy: 30, r: 18, fill: '#87CEEB' } },
      { type: 'text', props: { x: 150, y: 35, fontSize: 10, fill: '#333' }, children: 'Aa' },
      { type: 'text', props: { x: 143, y: 60, fontSize: 9, fill: '#666' }, children: 'Father' },
      // Arrows down
      { type: 'path', props: { d: 'M60 50 L80 85', stroke: '#333', strokeWidth: 1, fill: 'none' } },
      { type: 'path', props: { d: 'M160 50 L140 85', stroke: '#333', strokeWidth: 1, fill: 'none' } },
      // Offspring boxes (Punnett square results)
      { type: 'rect', props: { x: 30, y: 90, width: 35, height: 25, fill: '#FFB6C1', rx: 4 } },
      { type: 'text', props: { x: 38, y: 107, fontSize: 10, fill: '#333' }, children: 'AA' },
      { type: 'rect', props: { x: 75, y: 90, width: 35, height: 25, fill: '#E6E6FA', rx: 4 } },
      { type: 'text', props: { x: 85, y: 107, fontSize: 10, fill: '#333' }, children: 'Aa' },
      { type: 'rect', props: { x: 120, y: 90, width: 35, height: 25, fill: '#E6E6FA', rx: 4 } },
      { type: 'text', props: { x: 130, y: 107, fontSize: 10, fill: '#333' }, children: 'Aa' },
      { type: 'rect', props: { x: 165, y: 90, width: 35, height: 25, fill: '#B0E0E6', rx: 4 } },
      { type: 'text', props: { x: 176, y: 107, fontSize: 10, fill: '#333' }, children: 'aa' },
      // Labels
      { type: 'text', props: { x: 30, y: 140, fontSize: 9, fill: '#333' }, children: '25% AA  50% Aa  25% aa' },
      { type: 'text', props: { x: 50, y: 155, fontSize: 9, fill: '#666' }, children: '75% Dominant : 25% Recessive' },
    ],
  },
};

const GRADE_9_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 9,
  mode: 'auditory',
  question: 'Suri, ano ang heredity?',
  responseText:
    'Ang heredity ay ang pagpapasa ng traits mula sa parents papunta sa offspring through genes sa DNA.',
  ttsText:
    'Ang heredity ay ang proseso kung paano naipapasa ang mga traits mula sa magulang papunta sa anak. ' +
    'Nangyayari ito through DNA, na naka-organize sa mga genes. Bawat gene ay may alleles, isa galing sa nanay, isa sa tatay. ' +
    'Kapag dominant ang isang allele, siya ang lalabas na trait. Kapag parehong recessive, saka lang lalabas ang recessive trait. ' +
    'Halimbawa, kung brown eyes ay dominant at blue eyes ay recessive, kailangan mo ng dalawang recessive alleles para magkaroon ng blue eyes.',
};

const GRADE_9_READING: OnboardingDemoResponse = {
  gradeLevel: 9,
  mode: 'reading',
  question: 'Suri, ano ang heredity?',
  responseText:
    '**Heredity — Pagpapasa ng Traits**\n\n' +
    '• **DNA** — blueprint ng katawan, naka-organize sa chromosomes\n' +
    '• **Genes** — specific instructions para sa isang trait (ex: eye color)\n' +
    '• **Alleles** — versions ng isang gene (isa mula sa nanay, isa sa tatay)\n\n' +
    '**Dominant vs Recessive:**\n' +
    '• Dominant (A) — lalabas kahit isa lang ang copy\n' +
    '• Recessive (a) — lalabas LANG kung pareho ang dalawang copies (aa)\n\n' +
    '**Punnett Square (Aa × Aa):** 25% AA, 50% Aa, 25% aa',
};

const GRADE_9_MIXED: OnboardingDemoResponse = {
  gradeLevel: 9,
  mode: 'mixed',
  question: 'Suri, ano ang heredity?',
  responseText:
    'Heredity = pagpapasa ng traits via DNA/genes. Dominant allele (A) lalabas; recessive (a) kailangan dalawa (aa) para lumabas.',
  textFallback: 'Parents: Aa × Aa → 75% dominant, 25% recessive.',
  svgSpec: {
    viewBox: '0 0 140 80',
    elements: [
      { type: 'circle', props: { cx: 35, cy: 25, r: 12, fill: '#DDA0DD' } },
      { type: 'text', props: { x: 28, y: 30, fontSize: 9, fill: '#333' }, children: 'Aa' },
      { type: 'circle', props: { cx: 105, cy: 25, r: 12, fill: '#87CEEB' } },
      { type: 'text', props: { x: 98, y: 30, fontSize: 9, fill: '#333' }, children: 'Aa' },
      { type: 'path', props: { d: 'M45 37 L60 55', stroke: '#333', strokeWidth: 1, fill: 'none' } },
      { type: 'path', props: { d: 'M95 37 L80 55', stroke: '#333', strokeWidth: 1, fill: 'none' } },
      { type: 'text', props: { x: 30, y: 72, fontSize: 9, fill: '#333' }, children: 'AA  Aa  Aa  aa' },
    ],
  },
};

// ---------------------------------------------------------------------------
// Demo Responses — Grade 10
// ---------------------------------------------------------------------------

const GRADE_10_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 10,
  mode: 'visual',
  question: 'Suri, ano ang electromagnetic wave?',
  responseText: 'Eto ang EM spectrum — mula radio waves hanggang gamma rays!',
  textFallback:
    'EM Spectrum (low to high frequency): Radio → Microwave → Infrared → Visible Light → UV → X-ray → Gamma Ray.',
  svgSpec: {
    viewBox: '0 0 300 100',
    elements: [
      // Spectrum bar
      { type: 'rect', props: { x: 10, y: 35, width: 40, height: 20, fill: '#8B0000', rx: 3 } },
      { type: 'rect', props: { x: 52, y: 35, width: 40, height: 20, fill: '#FF4500', rx: 3 } },
      { type: 'rect', props: { x: 94, y: 35, width: 40, height: 20, fill: '#FF0000', rx: 3 } },
      { type: 'rect', props: { x: 136, y: 35, width: 40, height: 20, fill: '#FFD700', rx: 3 } },
      { type: 'rect', props: { x: 178, y: 35, width: 40, height: 20, fill: '#9400D3', rx: 3 } },
      { type: 'rect', props: { x: 220, y: 35, width: 38, height: 20, fill: '#4169E1', rx: 3 } },
      { type: 'rect', props: { x: 260, y: 35, width: 30, height: 20, fill: '#000080', rx: 3 } },
      // Labels
      { type: 'text', props: { x: 12, y: 72, fontSize: 7, fill: '#333' }, children: 'Radio' },
      { type: 'text', props: { x: 50, y: 72, fontSize: 7, fill: '#333' }, children: 'Micro-' },
      { type: 'text', props: { x: 50, y: 82, fontSize: 7, fill: '#333' }, children: 'wave' },
      { type: 'text', props: { x: 97, y: 72, fontSize: 7, fill: '#333' }, children: 'Infrared' },
      { type: 'text', props: { x: 140, y: 72, fontSize: 7, fill: '#333' }, children: 'Visible' },
      { type: 'text', props: { x: 190, y: 72, fontSize: 7, fill: '#333' }, children: 'UV' },
      { type: 'text', props: { x: 222, y: 72, fontSize: 7, fill: '#333' }, children: 'X-ray' },
      { type: 'text', props: { x: 260, y: 72, fontSize: 7, fill: '#333' }, children: 'Gamma' },
      // Arrow showing increasing frequency
      { type: 'path', props: { d: 'M10 25 L290 25', stroke: '#333', strokeWidth: 1, fill: 'none' } },
      { type: 'path', props: { d: 'M285 22 L290 25 L285 28', fill: '#333' } },
      { type: 'text', props: { x: 100, y: 18, fontSize: 8, fill: '#666' }, children: 'Frequency →  (mataas = mas malakas energy)' },
    ],
  },
};

const GRADE_10_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 10,
  mode: 'auditory',
  question: 'Suri, ano ang electromagnetic wave?',
  responseText:
    'Ang electromagnetic waves ay mga waves na gawa sa oscillating electric at magnetic fields. Kasama dito ang visible light, radio waves, X-rays, at iba pa.',
  ttsText:
    'Ang electromagnetic waves ay energy na nag-travel through space bilang waves. ' +
    'Hindi nila kailangan ng medium, kaya nag-travel sila kahit sa vacuum ng space. ' +
    'Ang EM spectrum ay naka-arrange ayon sa frequency: mula sa radio waves na mababa ang frequency, ' +
    'hanggang sa gamma rays na mataas ang frequency at mataas ang energy. ' +
    'Ang visible light, yung nakikita natin, nasa gitna lang ng spectrum. ' +
    'Mas mataas ang frequency, mas mataas ang energy. Kaya ang gamma rays ay mas dangerous kaysa radio waves.',
};

const GRADE_10_READING: OnboardingDemoResponse = {
  gradeLevel: 10,
  mode: 'reading',
  question: 'Suri, ano ang electromagnetic wave?',
  responseText:
    '**Electromagnetic Waves**\n\n' +
    '• Waves na gawa sa oscillating electric + magnetic fields\n' +
    '• Hindi kailangan ng medium (travels through vacuum)\n' +
    '• Speed sa vacuum: 3 × 10⁸ m/s (speed of light)\n\n' +
    '**EM Spectrum (low → high frequency):**\n' +
    '1. Radio waves — communication, radio\n' +
    '2. Microwaves — cooking, WiFi\n' +
    '3. Infrared — heat, remote controls\n' +
    '4. Visible light — colors na nakikita natin\n' +
    '5. Ultraviolet — sunburn, sterilization\n' +
    '6. X-rays — medical imaging\n' +
    '7. Gamma rays — cancer treatment, nuclear\n\n' +
    '**Key rule:** Higher frequency = higher energy = shorter wavelength',
};

const GRADE_10_MIXED: OnboardingDemoResponse = {
  gradeLevel: 10,
  mode: 'mixed',
  question: 'Suri, ano ang electromagnetic wave?',
  responseText:
    'EM waves = energy na nag-travel as oscillating fields. Spectrum: Radio → Micro → IR → Visible → UV → X-ray → Gamma. Higher freq = more energy.',
  textFallback:
    'EM Spectrum: Radio < Microwave < Infrared < Visible < UV < X-ray < Gamma. Higher frequency = higher energy.',
  svgSpec: {
    viewBox: '0 0 180 50',
    elements: [
      { type: 'rect', props: { x: 5, y: 15, width: 22, height: 14, fill: '#8B0000', rx: 2 } },
      { type: 'rect', props: { x: 30, y: 15, width: 22, height: 14, fill: '#FF4500', rx: 2 } },
      { type: 'rect', props: { x: 55, y: 15, width: 22, height: 14, fill: '#FF0000', rx: 2 } },
      { type: 'rect', props: { x: 80, y: 15, width: 22, height: 14, fill: '#FFD700', rx: 2 } },
      { type: 'rect', props: { x: 105, y: 15, width: 22, height: 14, fill: '#9400D3', rx: 2 } },
      { type: 'rect', props: { x: 130, y: 15, width: 22, height: 14, fill: '#4169E1', rx: 2 } },
      { type: 'rect', props: { x: 155, y: 15, width: 22, height: 14, fill: '#000080', rx: 2 } },
      { type: 'path', props: { d: 'M5 8 L177 8', stroke: '#333', strokeWidth: 0.8, fill: 'none' } },
      { type: 'text', props: { x: 60, y: 45, fontSize: 7, fill: '#666' }, children: 'Frequency → (more energy)' },
    ],
  },
};

// ---------------------------------------------------------------------------
// Demo Responses — Grade 11
// ---------------------------------------------------------------------------

const GRADE_11_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 11,
  mode: 'visual',
  question: 'Suri, ano ang DNA replication?',
  responseText: 'Ganito nagco-copy ang DNA mo!',
  textFallback: 'DNA double helix unwinds → each strand serves as template → new complementary strand built → two identical copies.',
  svgSpec: {
    viewBox: '0 0 240 120',
    elements: [
      { type: 'path', props: { d: 'M30 60 Q60 30 90 60 Q120 90 150 60 Q180 30 210 60', stroke: '#E53935', strokeWidth: 3, fill: 'none' } },
      { type: 'path', props: { d: 'M30 60 Q60 90 90 60 Q120 30 150 60 Q180 90 210 60', stroke: '#1E88E5', strokeWidth: 3, fill: 'none' } },
      { type: 'line', props: { x1: 50, y1: 48, x2: 50, y2: 72, stroke: '#66BB6A', strokeWidth: 1.5 } },
      { type: 'line', props: { x1: 75, y1: 55, x2: 75, y2: 65, stroke: '#66BB6A', strokeWidth: 1.5 } },
      { type: 'line', props: { x1: 105, y1: 55, x2: 105, y2: 65, stroke: '#66BB6A', strokeWidth: 1.5 } },
      { type: 'line', props: { x1: 135, y1: 48, x2: 135, y2: 72, stroke: '#66BB6A', strokeWidth: 1.5 } },
      { type: 'line', props: { x1: 165, y1: 55, x2: 165, y2: 65, stroke: '#66BB6A', strokeWidth: 1.5 } },
      { type: 'line', props: { x1: 195, y1: 48, x2: 195, y2: 72, stroke: '#66BB6A', strokeWidth: 1.5 } },
      { type: 'text', props: { x: 70, y: 110, fontSize: 9, fill: '#333' }, children: 'DNA Double Helix → Replication Fork' },
    ],
  },
};

const GRADE_11_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 11,
  mode: 'auditory',
  question: 'Suri, ano ang DNA replication?',
  responseText: 'Ang DNA replication ay ang proseso kung paano ginagawan ng kopya ang DNA bago mag-cell division.',
  ttsText:
    'Ang DNA replication ay nangyayari bago mag-divide ang isang cell. Una, nagbu-unwind ang double helix — parang binubuksan mo ang zipper. ' +
    'Pangalawa, bawat strand ay nagsi-serve as template. Ang enzyme na helicase ang nagbu-break ng hydrogen bonds. ' +
    'Pangatlo, ang DNA polymerase ang nagdadagdag ng complementary nucleotides — A pairs with T, C pairs with G. ' +
    'Sa dulo, meron kang dalawang identical copies ng original DNA. Ito ang semiconservative replication — bawat copy may isang old strand at isang new strand.',
};

const GRADE_11_READING: OnboardingDemoResponse = {
  gradeLevel: 11,
  mode: 'reading',
  question: 'Suri, ano ang DNA replication?',
  responseText:
    '**DNA Replication — Semiconservative**\n\n' +
    '• **Purpose:** Copy DNA before cell division\n' +
    '• **Steps:**\n' +
    '  1. Helicase unwinds the double helix\n' +
    '  2. Each strand becomes a template\n' +
    '  3. DNA polymerase adds complementary bases (A-T, C-G)\n' +
    '  4. Result: 2 identical DNA molecules\n\n' +
    '• **Semiconservative:** each copy has 1 original + 1 new strand\n' +
    '• **Direction:** 5\' → 3\' (leading strand continuous, lagging strand in Okazaki fragments)',
};

const GRADE_11_MIXED: OnboardingDemoResponse = {
  gradeLevel: 11,
  mode: 'mixed',
  question: 'Suri, ano ang DNA replication?',
  responseText: 'DNA unwinds → each strand = template → polymerase builds complementary copy → 2 identical DNA molecules (semiconservative).',
  textFallback: 'Unwind → Template → Complementary bases → 2 copies. Semiconservative = 1 old + 1 new strand each.',
  svgSpec: {
    viewBox: '0 0 160 60',
    elements: [
      { type: 'path', props: { d: 'M10 30 Q30 15 50 30 Q70 45 90 30', stroke: '#E53935', strokeWidth: 2, fill: 'none' } },
      { type: 'path', props: { d: 'M10 30 Q30 45 50 30 Q70 15 90 30', stroke: '#1E88E5', strokeWidth: 2, fill: 'none' } },
      { type: 'path', props: { d: 'M95 25 L110 25', stroke: '#333', strokeWidth: 1, fill: 'none' } },
      { type: 'path', props: { d: 'M105 22 L110 25 L105 28', fill: '#333' } },
      { type: 'path', props: { d: 'M115 20 Q130 15 145 20', stroke: '#E53935', strokeWidth: 2, fill: 'none' } },
      { type: 'path', props: { d: 'M115 25 Q130 20 145 25', stroke: '#81C784', strokeWidth: 2, fill: 'none' } },
      { type: 'path', props: { d: 'M115 35 Q130 40 145 35', stroke: '#1E88E5', strokeWidth: 2, fill: 'none' } },
      { type: 'path', props: { d: 'M115 40 Q130 45 145 40', stroke: '#81C784', strokeWidth: 2, fill: 'none' } },
    ],
  },
};

// ---------------------------------------------------------------------------
// Demo Responses — Grade 12
// ---------------------------------------------------------------------------

const GRADE_12_VISUAL: OnboardingDemoResponse = {
  gradeLevel: 12,
  mode: 'visual',
  question: 'Suri, ano ang supply and demand?',
  responseText: 'Eto ang supply and demand curve!',
  textFallback: 'Demand: pag mataas presyo, kaunti bibili. Supply: pag mataas presyo, marami magbebenta. Equilibrium: kung saan nagtatagpo.',
  svgSpec: {
    viewBox: '0 0 200 160',
    elements: [
      { type: 'line', props: { x1: 30, y1: 130, x2: 180, y2: 130, stroke: '#333', strokeWidth: 1.5 } },
      { type: 'line', props: { x1: 30, y1: 130, x2: 30, y2: 20, stroke: '#333', strokeWidth: 1.5 } },
      { type: 'text', props: { x: 85, y: 150, fontSize: 9, fill: '#333' }, children: 'Quantity' },
      { type: 'text', props: { x: 5, y: 75, fontSize: 9, fill: '#333' }, children: 'Price' },
      { type: 'path', props: { d: 'M50 30 L160 120', stroke: '#1E88E5', strokeWidth: 2.5, fill: 'none' } },
      { type: 'text', props: { x: 155, y: 115, fontSize: 9, fill: '#1E88E5' }, children: 'Supply' },
      { type: 'path', props: { d: 'M50 120 L160 30', stroke: '#E53935', strokeWidth: 2.5, fill: 'none' } },
      { type: 'text', props: { x: 155, y: 35, fontSize: 9, fill: '#E53935' }, children: 'Demand' },
      { type: 'circle', props: { cx: 105, cy: 75, r: 5, fill: '#4CAF50' } },
      { type: 'text', props: { x: 112, y: 72, fontSize: 9, fill: '#4CAF50' }, children: 'Equilibrium' },
    ],
  },
};

const GRADE_12_AUDITORY: OnboardingDemoResponse = {
  gradeLevel: 12,
  mode: 'auditory',
  question: 'Suri, ano ang supply and demand?',
  responseText: 'Ang supply and demand ang basic na konsepto ng economics — kung paano nag-iinteract ang buyers at sellers sa market.',
  ttsText:
    'Ang law of demand: kapag tumaas ang presyo ng isang produkto, bababa ang demand — mas kaunti ang bibili. ' +
    'Ang law of supply: kapag tumaas ang presyo, tataas ang supply — mas marami ang gustong magbenta. ' +
    'Ang equilibrium price ay ang punto kung saan pantay ang supply at demand — doon nagtatagpo ang dalawang curves sa graph. ' +
    'Kapag ang presyo ay nasa ibaba ng equilibrium, shortage ang mangyayari. Kapag nasa itaas, surplus naman.',
};

const GRADE_12_READING: OnboardingDemoResponse = {
  gradeLevel: 12,
  mode: 'reading',
  question: 'Suri, ano ang supply and demand?',
  responseText:
    '**Supply and Demand**\n\n' +
    '• **Law of Demand:** ↑ Price → ↓ Quantity Demanded\n' +
    '• **Law of Supply:** ↑ Price → ↑ Quantity Supplied\n\n' +
    '**Equilibrium:**\n' +
    '• Punto kung saan Supply = Demand\n' +
    '• Below equilibrium → Shortage (maraming buyers, kaunti sellers)\n' +
    '• Above equilibrium → Surplus (maraming sellers, kaunti buyers)\n\n' +
    '**Shifts:** Non-price factors (income, taste, technology) shift the entire curve',
};

const GRADE_12_MIXED: OnboardingDemoResponse = {
  gradeLevel: 12,
  mode: 'mixed',
  question: 'Suri, ano ang supply and demand?',
  responseText: 'Demand: ↑price → ↓buyers. Supply: ↑price → ↑sellers. Equilibrium: kung saan nagtatagpo (market price).',
  textFallback: 'Demand goes down as price rises. Supply goes up as price rises. Equilibrium is where they meet.',
  svgSpec: {
    viewBox: '0 0 120 90',
    elements: [
      { type: 'line', props: { x1: 15, y1: 75, x2: 110, y2: 75, stroke: '#333', strokeWidth: 1 } },
      { type: 'line', props: { x1: 15, y1: 75, x2: 15, y2: 10, stroke: '#333', strokeWidth: 1 } },
      { type: 'path', props: { d: 'M25 15 L100 70', stroke: '#1E88E5', strokeWidth: 2, fill: 'none' } },
      { type: 'path', props: { d: 'M25 70 L100 15', stroke: '#E53935', strokeWidth: 2, fill: 'none' } },
      { type: 'circle', props: { cx: 62, cy: 43, r: 3, fill: '#4CAF50' } },
    ],
  },
};

// ---------------------------------------------------------------------------
// Demo Content Collection & Lookup
// ---------------------------------------------------------------------------

const ONBOARDING_DEMOS: OnboardingDemoResponse[] = [
  // Grade 1
  GRADE_1_VISUAL, GRADE_1_AUDITORY, GRADE_1_READING, GRADE_1_MIXED,
  // Grade 2
  GRADE_2_VISUAL, GRADE_2_AUDITORY, GRADE_2_READING, GRADE_2_MIXED,
  // Grade 3
  GRADE_3_VISUAL, GRADE_3_AUDITORY, GRADE_3_READING, GRADE_3_MIXED,
  // Grade 4
  GRADE_4_VISUAL, GRADE_4_AUDITORY, GRADE_4_READING, GRADE_4_MIXED,
  // Grade 5
  GRADE_5_VISUAL, GRADE_5_AUDITORY, GRADE_5_READING, GRADE_5_MIXED,
  // Grade 6
  GRADE_6_VISUAL, GRADE_6_AUDITORY, GRADE_6_READING, GRADE_6_MIXED,
  // Grade 7
  GRADE_7_VISUAL, GRADE_7_AUDITORY, GRADE_7_READING, GRADE_7_MIXED,
  // Grade 8
  GRADE_8_VISUAL, GRADE_8_AUDITORY, GRADE_8_READING, GRADE_8_MIXED,
  // Grade 9
  GRADE_9_VISUAL, GRADE_9_AUDITORY, GRADE_9_READING, GRADE_9_MIXED,
  // Grade 10
  GRADE_10_VISUAL, GRADE_10_AUDITORY, GRADE_10_READING, GRADE_10_MIXED,
  // Grade 11
  GRADE_11_VISUAL, GRADE_11_AUDITORY, GRADE_11_READING, GRADE_11_MIXED,
  // Grade 12
  GRADE_12_VISUAL, GRADE_12_AUDITORY, GRADE_12_READING, GRADE_12_MIXED,
];

/**
 * Look up the pre-built demo response for a given grade level and mode.
 * Returns the Grade 6 Mixed response as fallback if no exact match is found.
 */
export function getDemoContent(
  grade: number,
  mode: ResponseMode,
): OnboardingDemoResponse {
  const match = ONBOARDING_DEMOS.find(
    (d) => d.gradeLevel === grade && d.mode === mode,
  );
  // Fallback: Grade 6 Mixed (always exists)
  return match ?? GRADE_6_MIXED;
}

export { ONBOARDING_DEMOS };

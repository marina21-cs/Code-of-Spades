/**
 * Screen 4: Learning Mode Picker — 4 cards in a 2×2 grid.
 */
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { ModeCardGrid } from '../components/ModeCardGrid';
import type { ModeScreenProps } from '../types';

export function ModeScreen({ onSelectMode, onSkip, reduceMotion }: ModeScreenProps) {
  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.question}>Paano mo gustong matuto?</Text>
        <ModeCardGrid onSelectMode={onSelectMode} />
      </View>

      <Pressable
        onPress={onSkip}
        style={styles.skipButton}
        accessibilityRole="button"
        accessibilityLabel="Laktawan — Halo-halo ang default"
      >
        <Text style={styles.skipText}>Laktawan (Halo-halo ang default)</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 40,
    paddingBottom: 12,
  },
  content: {
    alignItems: 'center',
    gap: 18,
  },
  question: {
    fontSize: 18,
    fontWeight: '600',
    color: '#4A3728',
    textAlign: 'center',
  },
  skipButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    minHeight: 48,
    justifyContent: 'center',
  },
  skipText: {
    fontSize: 14,
    color: '#9A7A5A',
    textDecorationLine: 'underline',
  },
});

# Feature Spec: Suri Onboarding — Feature Showcase + Learning Profile Setup

## Overview
- **Feature:** First-run onboarding flow that introduces Suri, personalizes grade level and learning mode, demonstrates it live with grade-appropriate content, and reveals curriculum grounding — all in 6 screens
- **Complexity:** Medium (8–15 files: screens, components, profile storage, navigation guards)
- **Estimated scope:** 10–14 files to create/modify, ~2–3 days implementation
- **Related features:** Learning Profile (expo-secure-store), AI Router (tier system), Local RAG, TTS (expo-speech), Suri Mascot animations

## Problem & Motivation

Suri's target users are Grades 4–10 Filipino students — many in rural areas, many without consistent adult tech guidance. They need to understand three things immediately:
1. This app works even without internet (so they won't hesitate to use it at home)
2. They can talk to Suri like a study buddy (not a search engine)
3. The answers come from their actual DepEd curriculum (not random internet content)

Without onboarding, students would open the app to a blank chat screen with no context. The onboarding builds trust, sets expectations, and personalizes the experience — all in under 2 minutes, with zero account creation and zero paywall.

## User Stories

- **As a** Grade 6 student opening Suri for the first time, **I want to** understand what Suri can do for me **so that** I trust it enough to ask my first question.
- **As a** student with limited data/Wi-Fi, **I want to** know upfront that Suri works offline **so that** I don't worry about wasting mobile data or losing my study session.
- **As a** student who learns better by listening than reading, **I want to** tell Suri how I learn best **so that** answers come in a format I actually understand.
- **As a** Grade 4 student, **I want** the app to talk to me at my level **so that** explanations aren't too hard or too easy.

## Activation Definition

**Aha Moment:** The student sees Suri answer a grade-appropriate question in their chosen learning mode during onboarding (Screen 5), then immediately enters the Chat tab ready to ask their own question.

**Activation Event:** First real AI response delivered in the student's chosen mode after onboarding completes.

---

## Detailed Requirements

### Flow Architecture (6 Screens)

```
Screen 1: Meet Suri (Welcome — "Ako si Suri!")
    ↓
Screen 2: Feature — Works Offline (Suri introduces what she can do)
    ↓
Screen 3: Grade Level Picker (Suri asks about you — earned the right to ask)
    ↓
Screen 4: Learning Mode Picker (How do you want to learn? Skip = Mixed)
    ↓
Screen 5: Study Buddy Live Demo (grade-appropriate, mode-appropriate mock chat — merged study buddy showcase + live demo)
    ↓
Screen 6: DepEd Curriculum Reveal (payoff: "That answer came from your official lessons") → Done → Chat Tab
```

**Why this order:**
1. Suri introduces herself first (Screen 1) — basic courtesy
2. Suri shows what she can do (Screen 2) — establishes value
3. Suri asks the student's grade (Screen 3) — now the student understands *why* she's asking (to calibrate the help she just promised)
4. Suri asks how they want to learn (Screen 4) — deeper personalization
5. Suri demonstrates with a real example (Screen 5) — proof it works, tailored to BOTH their grade and their mode
6. Suri reveals the source (Screen 6) — "that answer came from your real curriculum" — trust earned through demonstration, not claimed upfront

**Global UX rules for all screens:**
- Progress dots at bottom (6 dots, current highlighted)
- Swipe left/right navigation between screens (via `react-native-gesture-handler`)
- "Susunod" (Next) button as primary CTA on each screen
- "Laktawan" (Skip) link on Screen 2 that jumps directly to Screen 3
- All copy in Filipino with natural English code-switching (how students actually talk)
- No account creation. No sign-up. No email. No paywall. Zero friction.
- Suri mascot visible on every screen (different poses/animations per screen)
- Respects `lowMotion` system accessibility setting even before profile is created (check OS `prefers-reduced-motion` or Android "Remove animations" setting)

---

### Screen 1: Meet Suri (Welcome)

**Description:** Warm introduction. The student meets the fox mascot for the first time. Suri introduces herself — no questions asked yet.

**UI/UX:**
- **Layout:** Full-screen, warm orange/cream gradient background. Suri mascot centered (large, ~40% of viewport height) in her idle breathing animation. Below: app name "Suri" in display font, tagline, and CTA button.
- **Suri state:** Idle → transitions to a small wave/greeting animation on screen appear
- **Copy:**
  ```
  [Suri waving]
  
  "Kamusta! Ako si Suri 🦊"
  
  "Kasama mo ako sa pag-aaral — 
   kahit walang internet."
  
  [Button: "Tara, kilalanin mo ako!"]
  ```
- **Interactions:** Single CTA button advances to Screen 2. No back button (first screen).
- **Accessibility:** Button is large (min 48dp touch target), high contrast text on gradient. TTS does not auto-play here — it's a visual welcome.

**States:**
| State | What the user sees | Trigger |
|---|---|---|
| Default | Welcome screen with Suri animation | First app launch, `onboardingComplete` flag is `false` in expo-secure-store |
| Low Motion | Suri is a static illustration (no breathing animation) | OS accessibility: reduce motion enabled |

---

### Screen 2: Feature Showcase — Works Offline

**Description:** Suri's #1 value prop: she works without internet. Uses a simple visual metaphor, not technical jargon. This is Suri telling the student what she can do — building value before asking anything.

**UI/UX:**
- **Layout:** Illustration area (top 50%) showing an animated sequence: signal bars dropping to zero → Suri stays bright and active. Below: short explanation + CTA.
- **Suri state:** Confident pose (paw on hip or thumbs up). A small *buwan* (moon) icon appears above her head as the signal drops — matching the "Suri Local" visual state from the spec.
- **Copy:**
  ```
  [Animated: signal bars disappearing, Suri still glowing]
  
  "Walang WiFi? Okay lang!"
  
  "Nag-iisip ako kahit walang signal.
   Pwede mo akong kausapin 
   kahit saan, kahit kailan."
  
  [Button: "Susunod →"]
  [Link: "Laktawan" (Skip to grade picker)]
  ```
- **Interactions:** "Susunod" advances to Screen 3. "Laktawan" jumps to Screen 3 (grade level — the first required input).
- **Key message (for student):** "I don't need internet to help you study."
- **NOT mentioned:** llama.rn, SmolLM2, tiers, technical architecture. Students don't need to know how — just that it works.

---

### Screen 3: Grade Level Picker

**Description:** Suri's first question to the student. She's introduced herself and shown what she can do — now she earns the right to ask. Framed as Suri getting to know you (conversational), not as a form field.

**Why here (not last):** Grade level determines the content shown on Screen 5 (the live demo). By asking grade early, the demo can show a grade-appropriate question — making it immediately relatable. A Grade 4 student sees Grade 4 content, a Grade 10 student sees Grade 10 content.

**UI/UX:**
- **Layout:** Suri in curious pose at top (~30% height). Question text in the middle. Large tappable grade buttons arranged in rows. CTA enables after selection.
- **Suri state:** Curious pose (head tilted, ears perked) — "I'm getting to know you"
- **Copy:**
  ```
  [Suri curious, head tilted]
  
  "Para ma-match ko yung level mo —
   anong grade mo na?"
  
  [Large buttons, 2-column or 3-column grid:]
  
  Grade 4    Grade 5    Grade 6
  Grade 7    Grade 8    Grade 9
  Grade 10
  
  [Button after selection: "Susunod →"]
  ```

**Interaction:**
- Tapping a grade highlights it (selected state with visible border/fill change)
- "Susunod" button appears/enables after selection
- Grade level is stored temporarily in component state until final save on Screen 6
- No skip option — grade is required for the demo to work. But it's a single tap, zero cognitive load.

**Accessibility:**
- Buttons are min 48dp height, clearly labeled with "Grade [N]"
- Selected state uses both color AND a checkmark/border (not color-only)
- Works fine for the target age: every student knows their grade number

---

### Screen 4: Learning Mode Picker

**Description:** The core personalization moment. Determines how Suri formats every future response. Uses a simple, visual picker — NOT a 5-question quiz (to keep it fast and easy for younger students to answer independently).

**UI/UX:**
- **Layout:** Question at top, then 4 large tappable cards arranged in a 2×2 grid. Each card has an icon, a short Filipino label, and a one-line description. Below the grid: "Skip" link.
- **Suri state:** Curious pose (head tilted, ears perked) — "I'm listening to your choice."
- **Copy:**
  ```
  "Paano mo gustong matuto?"
  
  [4 cards, 2×2 grid:]
  
  ┌─────────────────┐  ┌─────────────────┐
  │   👁️ Tignan      │  │   👂 Pakinggan   │
  │                 │  │                 │
  │  "Mas gusto ko  │  │  "Mas gusto ko  │
  │   makita sa     │  │   marinig ang   │
  │   drawing."     │  │   explanation." │
  └─────────────────┘  └─────────────────┘
  
  ┌─────────────────┐  ┌─────────────────┐
  │   📖 Basahin     │  │   🔀 Halo-halo  │
  │                 │  │                 │
  │  "Mas gusto ko  │  │  "Okay lang     │
  │   basahin nang  │  │   kahit ano —   │
  │   maayos."      │  │   bahala ka."   │
  └─────────────────┘  └─────────────────┘
  
  [Link at bottom: "Laktawan (Halo-halo ang default)"]
  ```

**Interaction logic:**
| Action | Result |
|---|---|
| Tap "Tignan" (Visual) | `responseMode = 'visual'` → advance to Screen 5 |
| Tap "Pakinggan" (Auditory) | `responseMode = 'auditory'` → advance to Screen 5 |
| Tap "Basahin" (Reading) | `responseMode = 'reading'` → advance to Screen 5 |
| Tap "Halo-halo" (Mixed) | `responseMode = 'mixed'` → advance to Screen 5 |
| Tap "Laktawan" (Skip) | `responseMode = 'mixed'` → advance to Screen 5 |

**Design decisions:**
- **Why 4 choices instead of the spec's 5-question quiz?** The target includes Grade 4 students (ages 9–10). A 5-question quiz with side-by-side comparisons is cognitively heavy for younger students. A single visual pick is faster, clearer, and they can do it without help. The spec explicitly allows "skip to manual selection" — this IS the manual selection, made primary.
- **Why no "Kinesthetic" card?** Kinesthetic mode (drag-and-drop quizzes) is harder to explain in a single card and is an advanced interaction. For onboarding simplicity, it's merged into Mixed. Can be surfaced later in Settings for students who want it.
- **"Halo-halo" naming:** Filipino term for "mixed" (literally a mixed dessert). Students immediately understand it. Fun, non-technical.

**Accessibility:**
- Cards have min 64dp height for easy tapping
- Each card has a distinct icon + text label (not icon-only)
- Selected card gets a visible border/highlight before advancing
- Works without color distinction (icon + text carry the meaning)

---

### Screen 5: Study Buddy Live Demo (Merged: Feature Showcase + Live Demo)

**Description:** This screen does double duty — it shows that Suri is a conversational study buddy AND demonstrates the student's chosen learning mode with grade-appropriate content. The student sees a mock chat where they "ask" a question and Suri responds in their selected format, using content from their actual grade level. This is the "aha moment."

**Why merged:** The original spec had a separate "study buddy" showcase (generic mock chat) and a "live demo" (mode-specific response). Merging them eliminates repetition and makes the demo feel more real — the student sees exactly what their future study sessions will look like.

**UI/UX:**
- **Layout:** Full mock chat interface. A pre-filled student bubble with a grade-appropriate question. Below it, Suri's response renders in the chosen mode (typing indicator → response). Below the chat area: confirmation text + CTA.
- **Suri state:** Thinking animation (ears perk, tail sweep) during the mock "typing" → Celebrating (bounce, tail wag) after the answer appears.

**Demo content is selected by grade level × learning mode:**

The question shown in the student bubble changes based on the grade selected on Screen 3. The response format changes based on the mode selected on Screen 4.

**Sample questions by grade (all from DepEd MELCs):**

| Grade | Sample Question (in student bubble) | Topic |
|---|---|---|
| Grade 4 | "Suri, ano ang mga bahagi ng halaman?" | Science: Parts of a plant |
| Grade 5 | "Suri, paano gumagalaw ang Earth?" | Science: Earth's rotation |
| Grade 6 | "Suri, ano ang photosynthesis?" | Science: Photosynthesis |
| Grade 7 | "Suri, ano ang atom?" | Science: Matter/Atoms |
| Grade 8 | "Suri, paano gumagana ang ecosystem?" | Science: Ecosystems |
| Grade 9 | "Suri, ano ang heredity?" | Science: Heredity/Genetics |
| Grade 10 | "Suri, ano ang electromagnetic wave?" | Science: EM Spectrum |

**Response format by mode (using Grade 6 as example):**

| Mode | What appears in Suri's response bubble |
|---|---|
| **Visual** | An SVG diagram renders inline: a plant with arrows showing sunlight → leaf → food. Labeled parts (CO₂, H₂O, glucose, O₂). Short caption: "Ganito ginagawa ng halaman ang pagkain niya!" |
| **Auditory** | Text response appears AND `expo-speech` TTS auto-plays it aloud: "Ang photosynthesis ay ang proseso kung paano gumagawa ng pagkain ang halaman gamit ang sikat ng araw, tubig, at carbon dioxide. Ang ginagawa niya, kino-convert niya ang light energy into food energy!" Audio wave ring animates around Suri. |
| **Reading** | Structured bullet-point response: "**Photosynthesis** • Proseso ng halaman para gumawa ng pagkain • Kailangan: sikat ng araw ☀️ + tubig 💧 + carbon dioxide • Resulta: glucose (pagkain) + oxygen • Nangyayari sa leaves (sa chloroplast)" |
| **Mixed** | A small SVG diagram (simplified) + 2-sentence explanation below it. Balanced visual + text. |

**Copy below the chat demo:**
```
"Ganyan kausap mo ako palagi — 
 parang kaklase mo lang! 🦊"

"Tanungin mo lang ako kahit ano 
 tungkol sa lessons mo."

[Button: "Susunod →"]
```

**Technical notes:**
- These are pre-built demo responses, NOT live AI calls. They're hardcoded content (JSON specs for SVG, strings for text/TTS) that match what the real system would produce.
- This ensures the onboarding works instantly offline on first launch — no API call, no model loading, no latency.
- TTS for auditory mode uses `expo-speech` with the same voice settings the real app will use.
- SVG for visual mode uses the same `react-native-svg` renderer the real app uses.
- The app bundles demo content for all 7 grade levels × 4 modes = 28 pre-built responses (lightweight — just JSON + strings).

---

### Screen 6: DepEd Curriculum Reveal + Completion

**Description:** The trust payoff. After the student has SEEN a relevant, accurate answer on Screen 5, this screen reveals WHY it was accurate: it came from the official DepEd curriculum. Trust earned through demonstration, not claimed abstractly.

This is also the final screen — it completes the onboarding and transitions to the app.

**UI/UX:**
- **Layout:** Top area shows a stylized DepEd badge/seal with a subtle "verified" checkmark animation. Middle: copy connecting the demo they just saw to the curriculum source. Bottom: final celebratory CTA.
- **Suri state:** Calm + proud pose. Holding a small book or pointing to the DepEd seal.
- **Copy:**
  ```
  [Visual: DepEd-style curriculum badge with ✓ animation]
  
  "Yung sagot ko kanina? 
   Galing 'yan sa DepEd curriculum mo."
  
  "Hindi ako nag-iimbento. 
   Lahat ng alam ko, galing sa 
   opisyal na lessons ng school mo."
  
  "Pwede mong baguhin kung paano 
   kausap mo ako anytime sa Settings."
  
  [Button: "Tara mag-aral! 🎉"]
  ```

**Interaction:**
- On tap of "Tara mag-aral!":
  1. Profile is saved to `expo-secure-store`:
     ```typescript
     {
       responseMode: 'visual' | 'auditory' | 'reading' | 'mixed',
       gradeLevel: 4 | 5 | 6 | 7 | 8 | 9 | 10,
       accessibilitySettings: {
         readerFont: false,
         colorVision: 'standard',
         highContrast: false,
         largeText: false,
         focusMode: false,
         lowMotion: false   // unless OS setting was detected
       },
       onboardingComplete: true
     }
     ```
  2. Navigation transitions to the main app (Chat tab)
  3. Suri greets in the Chat tab with a personalized welcome at their grade level:
     e.g., "Handa na ako! Ano ang gusto mong pag-aralan ngayon?" 

**Why DepEd reveal is last:**
- Showing "answers come from DepEd" BEFORE the student has seen a good answer is an abstract claim they have no reason to trust.
- Showing it AFTER they've seen a grade-appropriate, mode-appropriate, clearly accurate answer is proof by demonstration. "See that helpful answer? That came from your real lessons." — earned trust.
- It's also the natural emotional arc: intro → value → personalization → proof → "let's go!" The trust seal is the final reassurance before they start using the app for real.

---

## Data

### Learning Profile (stored in `expo-secure-store`)

```typescript
interface LearningProfile {
  responseMode: 'visual' | 'auditory' | 'reading' | 'kinesthetic' | 'mixed';
  gradeLevel: number; // 4–10
  accessibilitySettings: {
    readerFont: boolean;
    colorVision: 'standard' | 'deuteranopia' | 'protanopia' | 'tritanopia';
    highContrast: boolean;
    largeText: boolean;
    focusMode: boolean;
    lowMotion: boolean;
  };
}

interface OnboardingState {
  onboardingComplete: boolean;
  completedAt?: string; // ISO 8601
}
```

### Onboarding Demo Content (bundled, not fetched)

```typescript
interface OnboardingDemoResponse {
  gradeLevel: number;         // 4–10
  mode: 'visual' | 'auditory' | 'reading' | 'mixed';
  question: string;           // Filipino — what appears in the "student" bubble
  responseText: string;       // Filipino — Suri's text response
  svgSpec?: object;           // For visual/mixed modes — JSON → react-native-svg
  ttsText?: string;           // For auditory mode — what expo-speech reads aloud
}

// 7 grades × 4 modes = 28 pre-built demo responses, bundled in the app
const ONBOARDING_DEMOS: OnboardingDemoResponse[] = [/* ... */];
```

These are hardcoded in the app bundle. No network call during onboarding.

---

## Business Rules

1. **Onboarding runs exactly once.** If `onboardingComplete === true` in secure store, the app boots directly to the Chat tab. No re-showing.
2. **Onboarding is re-accessible from Settings.** A "Replay intro" option lets students re-do it (resets `onboardingComplete` and clears profile for fresh selection).
3. **No account required.** Zero authentication, zero email, zero phone number. The app is usable immediately.
4. **No paywall.** Nothing in onboarding (or the app) is gated behind payment. All features shown in onboarding are free and available immediately.
5. **Grade level is required.** No skip option on Screen 3 — it's a single-tap answer and the demo needs it. Every student knows their grade.
6. **Skip on mode picker assigns Mixed.** Skipping the mode picker (Screen 4) sets `responseMode = 'mixed'` and advances. The demo on Screen 5 shows a Mixed-format response.
7. **Profile is always editable.** The Profile tab allows changing response mode and grade level at any time. This is mentioned explicitly on Screen 6.
8. **Accessibility settings are NOT part of onboarding.** They're in Settings. The onboarding focuses on grade + learning mode. Accessibility toggles (Reader Font, High Contrast, etc.) are discoverable in the Profile tab — per the spec: "framed as 'how Suri talks to you,' purely user choice," not something you configure during a timed onboarding.
9. **Demo content is real curriculum.** The hardcoded demo responses on Screen 5 use actual DepEd MELC content for the student's grade — building trust from the first interaction and making the DepEd reveal on Screen 6 feel genuine.

---

## Edge Cases & Error Handling

| Scenario | Expected Behavior |
|---|---|
| Student force-closes app mid-onboarding | On next launch, onboarding restarts from Screen 1 (no partial state saved). Keep it simple — 6 screens take <90 seconds. |
| Student swipes back from Screen 5 to Screen 4 | Mode picker resets to no selection. Their previous pick is cleared. They can re-choose. |
| Student swipes back from Screen 4 to Screen 3 | Grade picker retains their selection (it's already saved in component state). They can change it. |
| TTS fails on Screen 5 (auditory demo) | Show the text response normally. Display a small note: "I-check ang TTS settings ng phone mo" — graceful degradation, not a crash. |
| Device has OS-level "reduce motion" enabled | Detect via `AccessibilityInfo` (React Native). Set `lowMotion: true` before onboarding starts. Suri is static on all screens. Animations replaced with crossfades. |
| Screen 5 SVG fails to render (visual/mixed demo) | Fall back to a text description of the diagram. The demo should never show an error state. |
| Student is Grade 3 or Grade 11+ | Not shown in picker. If they open Suri anyway, they can pick the closest grade. Grade 4 or Grade 10 covers the adjacent levels well enough. |
| Student re-installs the app | `expo-secure-store` is tied to the app installation. Re-install clears it. Onboarding runs again — which is fine, since there's no account to restore. |
| Extremely slow device (2016 budget phone) | Onboarding has no AI inference, no model loading, no network calls. It's pure UI. Even a 2GB RAM device handles this smoothly. |

---

## Performance Considerations

- **Zero network calls during onboarding.** All content is bundled. Works on airplane mode from first launch.
- **No AI model loading during onboarding.** The SLM model (llama.rn) is NOT initialized until after onboarding completes and the student enters the Chat tab. This prevents any memory pressure or lag during the intro.
- **28 demo responses** (7 grades × 4 modes) are lightweight — just JSON specs and strings. Total bundle impact: <50KB.
- **Lottie animations for Suri** are <200KB total (per spec). No performance concern.
- **SVG demo diagrams** are simple (5–10 path elements). Render instantly on any device.
- **Screen transitions** use `react-native-reanimated` with simple opacity/slide transforms — GPU-accelerated, no jank.

---

## Security Considerations

No additional security considerations beyond existing patterns. Onboarding:
- Collects no personal data (no name, no email, no phone)
- Makes no network requests
- Stores only a learning preference locally via `expo-secure-store`
- Has no authentication or authorization layer

---

## Analytics & Tracking (Local Only)

Since Suri has no backend, analytics are tracked locally in `expo-sqlite` for potential future sync:

| Event Name | Trigger | Properties |
|---|---|---|
| `onboarding_started` | Screen 1 appears | `{ timestamp }` |
| `onboarding_offline_viewed` | Screen 2 appears | `{ timestamp }` |
| `onboarding_grade_selected` | Grade tapped on Screen 3 | `{ grade: number, timestamp }` |
| `onboarding_mode_selected` | Mode card tapped on Screen 4 | `{ mode: string, wasSkip: boolean, timestamp }` |
| `onboarding_demo_played` | Screen 5 demo auto-plays | `{ grade: number, mode: string, ttsPlayed: boolean, svgRendered: boolean }` |
| `onboarding_completed` | "Tara mag-aral!" tapped on Screen 6 | `{ totalDurationMs: number, mode: string, grade: number }` |

---

## Out of Scope (Explicit Exclusions)

- **Accessibility settings in onboarding** — Deferred to Settings/Profile tab. Keeps onboarding short.
- **5-question comparative quiz** — The spec mentions this as one option; the single-pick card is simpler for the target age group. The quiz could be a future A/B test.
- **Kinesthetic mode in picker** — Merged into Mixed for onboarding simplicity. Available in Settings.
- **Account creation or sign-in** — Not part of onboarding or the app.
- **Notifications permission request** — Deferred to after first study session (better conversion when the student already sees value).
- **Model download prompt** — Shown separately after onboarding, when the student first tries to use the app offline. Not during intro.
- **Camera/microphone permissions** — Requested lazily on first use of those features, not during onboarding.
- **Parent/teacher dashboard setup** — Phase 2 feature (per spec).

---

## Open Questions

- [x] **Should the mode picker be a quiz or a direct pick?** Decision: Direct pick (4 cards). Rationale: Target includes Grade 4 students (9–10 years old) who need to complete this independently. A multi-step comparative quiz adds cognitive load.
- [x] **Should onboarding show accessibility settings?** Decision: No. Rationale: Adding 6 toggle options to onboarding overwhelms younger students. Accessibility settings are in Profile/Settings.
- [x] **Should grade level come before or after the feature showcase?** Decision: After the offline showcase (Screen 2), before the mode picker (Screen 4). Rationale: Suri needs to introduce herself first (courtesy), then grade level enables grade-appropriate demo content on Screen 5.
- [x] **Should the study buddy showcase and live demo be separate screens?** Decision: Merged into one screen (Screen 5). Rationale: Showing a generic mock chat AND a mode-specific demo is repetitive. One grade-appropriate, mode-appropriate demo shows both "I'm a study buddy" and "I adapt to you" simultaneously.
- [x] **Should DepEd curriculum info come before or after the demo?** Decision: After (Screen 6). Rationale: Trust earned by demonstration > trust claimed by assertion. The student sees a good answer THEN learns it came from official curriculum.
- [ ] **What specific MELC content appears per grade?** Default: Science topics per grade level (see Screen 5 table). Science is universally taught across all DepEd tracks and is visually demonstrable.

---

## Acceptance Criteria

- [ ] **GIVEN** a first-time user launches the app, **WHEN** `onboardingComplete` is `false` or missing, **THEN** the onboarding flow (Screen 1) appears instead of the main app.
- [ ] **GIVEN** a user has completed onboarding, **WHEN** they relaunch the app, **THEN** they land directly on the Chat tab (onboarding does not repeat).
- [ ] **GIVEN** the user is on Screen 2, **WHEN** they tap "Laktawan" (Skip), **THEN** they jump to Screen 3 (Grade Level Picker).
- [ ] **GIVEN** the user selects Grade 6 on Screen 3 and Visual on Screen 4, **WHEN** Screen 5 loads, **THEN** the mock chat shows a Grade 6 Science question with an SVG photosynthesis diagram response.
- [ ] **GIVEN** the user selects Grade 9 on Screen 3 and Auditory on Screen 4, **WHEN** Screen 5 loads, **THEN** the mock chat shows a Grade 9 Science question and TTS auto-plays the response.
- [ ] **GIVEN** the user taps "Laktawan" (Skip) on Screen 4, **WHEN** Screen 5 loads, **THEN** `responseMode` is set to `'mixed'` and the demo shows a Mixed-format response for their grade.
- [ ] **GIVEN** the user taps "Pakinggan" (Auditory) on Screen 4, **WHEN** Screen 5 loads, **THEN** TTS auto-plays the demo response AND an audio wave animation appears around Suri.
- [ ] **GIVEN** the user taps "Tara mag-aral!" on Screen 6, **WHEN** the onboarding completes, **THEN** the full LearningProfile is persisted to `expo-secure-store` with the chosen mode, grade, and default accessibility settings.
- [ ] **GIVEN** the device has no network connectivity (airplane mode), **WHEN** the user goes through the entire onboarding, **THEN** every screen renders correctly with no errors (zero network dependency).
- [ ] **GIVEN** the device has OS-level reduce-motion enabled, **WHEN** onboarding loads, **THEN** Suri is displayed as a static image and all transitions are simple crossfades.
- [ ] **GIVEN** TTS fails on the auditory demo (Screen 5), **WHEN** the response loads, **THEN** the text still appears normally and a helpful fallback message is shown (no crash or blank screen).
- [ ] **GIVEN** the entire onboarding flow, **WHEN** measured end-to-end, **THEN** a student can complete it in under 90 seconds at a comfortable pace.
- [ ] All onboarding screens have minimum 48dp touch targets for all interactive elements.
- [ ] All text passes WCAG AA contrast ratio (4.5:1 for body text, 3:1 for large text) against its background.
- [ ] No screen in the onboarding requests any device permissions (camera, microphone, notifications, location).
- [ ] No screen in the onboarding shows a paywall, upgrade prompt, or payment request.

---

## Recommended Skills for Implementation

| Skill | Purpose |
|---|---|
| `react-patterns` | Hooks, composition patterns for the screen flow |
| `mobile-design` | Touch targets, platform conventions, navigation patterns |
| `onboarding-cro` | Activation principles, time-to-value, progress indicators |
| `i18n-localization` | Filipino/English code-switching, string management |
| `frontend-design` | Visual polish, animation taste, anti-generic patterns |

---

## Summary: The Student's Experience

```
Open app for the first time
    ↓
"Kamusta! Ako si Suri!" (warm fox greeting — she introduces herself)
    ↓
"I work offline" (signal bars drop, Suri stays active — she shows what she can do)
    ↓
"Anong grade mo?" (single tap — she earns the right to ask)
    ↓
"Paano mo gustong matuto?" (4 big cards — how should I talk to you?)
    ↓
[Grade-appropriate mock chat in chosen mode] (proof it works — the aha moment)
    ↓
"That answer came from your DepEd curriculum" (trust seal — earned, not claimed)
    ↓
🎉 "Tara mag-aral!" → Chat tab opens, Suri greets you at your level
```

**The conversational logic:**
1. Hi, I'm Suri (introduction)
2. Here's what I can do (value)
3. What grade are you? (getting to know you)
4. How do you like things explained? (personalization)
5. Here — let me show you (demonstration with YOUR grade + YOUR mode)
6. And that came from your real lessons (trust) → Let's go!

Total time: ~60–90 seconds. 6 screens. Zero confusion. Zero paywall. Works offline from Screen 1.

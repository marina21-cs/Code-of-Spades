/**
 * Main app layout — placeholder for the tab navigation structure.
 * Will expand to include Chat, Profile, and Settings tabs.
 */
import { Slot } from 'expo-router';

export default function AppLayout() {
  return <Slot />;
}

/**
 * Mock chat interface for the onboarding demo (Screen 5).
 * Shows a student question bubble and Suri's response bubble.
 * Delegates response rendering to mode-specific sub-components.
 */
import { StyleSheet, Text, View } from 'react-native';

import type { OnboardingDemoResponse, ResponseMode } from '../types';
import { DemoResponseAuditory } from './DemoResponseAuditory';
import { DemoResponseMixed } from './DemoResponseMixed';
import { DemoResponseReading } from './DemoResponseReading';
import { DemoResponseVisual } from './DemoResponseVisual';

interface MockChatProps {
  content: OnboardingDemoResponse;
  reduceMotion: boolean;
  onTTSStatus?: (played: boolean) => void;
  onSVGStatus?: (rendered: boolean) => void;
}

export function MockChat({
  content,
  reduceMotion,
  onTTSStatus,
  onSVGStatus,
}: MockChatProps) {
  return (
    <View style={styles.container}>
      {/* Student bubble */}
      <View style={styles.studentBubble}>
        <Text style={styles.studentText}>{content.question}</Text>
      </View>

      {/* Suri response bubble */}
      <View style={styles.suriBubble}>
        {renderResponse(content, reduceMotion, onTTSStatus, onSVGStatus)}
      </View>
    </View>
  );
}

function renderResponse(
  content: OnboardingDemoResponse,
  reduceMotion: boolean,
  onTTSStatus?: (played: boolean) => void,
  onSVGStatus?: (rendered: boolean) => void,
) {
  switch (content.mode) {
    case 'visual':
      return <DemoResponseVisual content={content} onSVGStatus={onSVGStatus} />;
    case 'auditory':
      return (
        <DemoResponseAuditory
          content={content}
          reduceMotion={reduceMotion}
          onTTSStatus={onTTSStatus}
        />
      );
    case 'reading':
      return <DemoResponseReading content={content} />;
    case 'mixed':
      return <DemoResponseMixed content={content} onSVGStatus={onSVGStatus} />;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    gap: 12,
  },
  studentBubble: {
    alignSelf: 'flex-end',
    maxWidth: '80%',
    backgroundColor: '#E8F4FD',
    borderRadius: 16,
    borderBottomRightRadius: 4,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  studentText: {
    fontSize: 14,
    color: '#1A3A4A',
  },
  suriBubble: {
    alignSelf: 'flex-start',
    maxWidth: '90%',
    backgroundColor: '#FFF5ED',
    borderRadius: 16,
    borderBottomLeftRadius: 4,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
});

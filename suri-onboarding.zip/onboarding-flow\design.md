# Design: Suri Onboarding — Feature Showcase + Learning Profile Setup

## Overview
A 6-screen first-run onboarding flow using Expo Router file-based routing with a shared layout that manages swipe navigation, progress dots, and onboarding state. Screens are pure presentational components; state lives in a context provider scoped to the onboarding flow. Profile persistence uses the existing `profileStore.ts` + `useProfile.ts` hook.

## Architecture

### Routing Structure (Expo Router)
```
app/
├── _layout.tsx                    (existing — root layout with DB init)
├── onboarding.tsx                (single-file pager: all 6 screens, swipe nav, state)
├── (app)/
│   ├── _layout.tsx               (main app tab layout — future)
│   └── index.tsx                 (Chat tab placeholder)
└── index.tsx                     (entry redirect: checks isFirstRun → routes to onboarding or app)
```

### Why Single-File Pager (not Route Groups)
- All 6 screens share ephemeral state (grade, mode, currentIndex) — lifting to context adds indirection
- Swipe navigation is native to a pager component (no manual gesture wiring per route)
- The pager manages forward-gating naturally (disable swipe-forward until condition met)
- Simpler mental model: one file owns the full flow, screen components are imported
- Onboarding is transient (runs once, <90 seconds) — doesn't benefit from route-level code splitting

### State Management

**Local state in the pager component** (useState/useReducer, no Context needed):
```typescript
interface OnboardingState {
  gradeLevel: number | null;       // Set on Screen 3, required
  responseMode: ResponseMode | null; // Set on Screen 4, optional (default: mixed)
  currentPage: number;              // 0-5 index for pager + progress dots
  startTimestamp: number;           // For analytics duration calc
}
```

State lives directly in `app/onboarding.tsx` and is passed as props to screen sub-components. No Context needed — one parent owns the whole flow. State is intentionally NOT persisted — if the app closes, onboarding restarts fresh (per spec: "no partial state saved").

### Component Hierarchy

```
OnboardingScreen (app/onboarding.tsx — the pager)
├── PagerView (react-native-pager-view or ScrollView-based)
│   ├── Page 0: WelcomeScreen
│   │   └── SuriMascot (wave pose, respects reduceMotion)
│   ├── Page 1: OfflineScreen
│   │   ├── SignalBarAnimation (or static if reduceMotion)
│   │   └── SuriMascot (confident pose)
│   ├── Page 2: GradeScreen
│   │   ├── SuriMascot (curious pose)
│   │   └── GradeGrid (7 buttons, Grade 4–10)
│   ├── Page 3: ModeScreen
│   │   ├── SuriMascot (curious pose)
│   │   └── ModeCardGrid (4 cards, 2×2)
│   ├── Page 4: DemoScreen
│   │   ├── SuriMascot (thinking → celebrating)
│   │   ├── MockChatBubble (student question)
│   │   └── DemoResponse (mode-specific: SVG / TTS / text / mixed)
│   └── Page 5: CurriculumScreen
│       ├── DepEdBadge (seal + checkmark animation)
│       └── SuriMascot (proud pose)
├── ProgressDots (6 dots, current highlighted — positioned outside pager)
└── NavigationControls (CTA button per page — positioned outside pager)
```

### New Files to Create

| File | Purpose |
|---|---|
| `app/onboarding.tsx` | Single-file pager: manages all 6 screens, swipe nav, state, progress dots |
| `src/onboarding/types.ts` | Onboarding-specific type definitions |
| `src/onboarding/demoContent.ts` | 28 pre-built demo responses (7 grades × 4 modes) |
| `src/onboarding/analytics.ts` | Local event tracking helpers (writes to expo-sqlite) |
| `src/onboarding/useReduceMotion.ts` | Hook: detects OS accessibility setting |
| `src/onboarding/screens/WelcomeScreen.tsx` | Screen 1: Meet Suri |
| `src/onboarding/screens/OfflineScreen.tsx` | Screen 2: Works Offline |
| `src/onboarding/screens/GradeScreen.tsx` | Screen 3: Grade Level Picker |
| `src/onboarding/screens/ModeScreen.tsx` | Screen 4: Learning Mode Picker |
| `src/onboarding/screens/DemoScreen.tsx` | Screen 5: Live Demo |
| `src/onboarding/screens/CurriculumScreen.tsx` | Screen 6: DepEd Reveal + Completion |
| `src/onboarding/components/ProgressDots.tsx` | 6-dot progress indicator |
| `src/onboarding/components/SuriMascot.tsx` | Mascot component with pose prop, respects reduceMotion |
| `src/onboarding/components/GradeGrid.tsx` | Grade 4–10 button grid |
| `src/onboarding/components/ModeCard.tsx` | Single mode card (icon, label, description) |
| `src/onboarding/components/ModeCardGrid.tsx` | 2×2 grid of ModeCards |
| `src/onboarding/components/MockChat.tsx` | Mock chat interface (student bubble + Suri bubble) |
| `src/onboarding/components/DemoResponseVisual.tsx` | SVG diagram renderer with fallback |
| `src/onboarding/components/DemoResponseAuditory.tsx` | Text + TTS auto-play + audio wave |
| `src/onboarding/components/DemoResponseReading.tsx` | Structured bullet-point text |
| `src/onboarding/components/DemoResponseMixed.tsx` | Small SVG + short text explanation |
| `src/onboarding/components/DepEdBadge.tsx` | DepEd seal with checkmark animation |
| `app/(app)/_layout.tsx` | Main app layout (minimal placeholder) |
| `app/(app)/index.tsx` | Chat tab placeholder |
| `app/index.tsx` | Entry redirect (first-run check) |

### Files to Modify

| File | Change |
|---|---|
| `package.json` | Add: `react-native-gesture-handler`, `react-native-reanimated`, `react-native-svg`, `lottie-react-native`, `react-native-pager-view` |
| `babel.config.js` | Add `react-native-reanimated/plugin` |
| `app/_layout.tsx` | Wrap with GestureHandlerRootView |

## Data Flow

### Profile Save (Screen 6 → expo-secure-store)
```
User taps "Tara mag-aral!"
  → onboarding.tsx state provides { gradeLevel, responseMode }
  → Build LearningProfile with defaults for accessibility
  → Call saveProfile(profile) from existing profileStore.ts
  → Call markFirstRunComplete() from existing profileStore.ts
  → Log onboarding_completed event
  → router.replace('/(app)')
```

### Demo Content Selection (Screen 5)
```
OnboardingState.gradeLevel + OnboardingState.responseMode
  → getDemoContent(grade, mode) indexes into ONBOARDING_DEMOS
  → Render mode-specific component with demo data
  → If auditory: trigger speak() from existing tts.ts
```

### First-Run Check (app/index.tsx)
```
App launches → _layout.tsx runs DB init → index.tsx mounts
  → Call isFirstRun() from existing profileStore.ts
  → If true: router.replace('/onboarding')
  → If false: router.replace('/(app)')
```

### Pager Navigation
```
OnboardingScreen manages currentPage state
  → PagerView ref.setPage(n) for programmatic navigation
  → onPageSelected callback updates currentPage
  → Forward swipe gated: scrollEnabled per page based on conditions
     - Page 2 (Grade): blocked until gradeLevel !== null
     - Other pages: always allow forward swipe OR advance on CTA tap
```

## Dependencies to Add

| Package | Version | Purpose |
|---|---|---|
| `react-native-gesture-handler` | `~2.24.0` | Required by pager-view and root gesture handling |
| `react-native-reanimated` | `~3.18.0` | Smooth animations, respects reduceMotion |
| `react-native-svg` | `~15.11.0` | SVG diagram rendering for visual mode demos |
| `react-native-pager-view` | `~7.1.0` | Native pager for swiping between onboarding screens |
| `lottie-react-native` | `~7.2.0` | Suri mascot animations (Lottie JSON) |

## Design Decisions

1. **Single-file pager over Expo Router route groups**: The onboarding flow is ephemeral (<90 seconds), has shared transient state (grade, mode, page index), and needs native swipe navigation. A PagerView in one route file keeps state co-located, eliminates Context indirection, and provides native iOS/Android paging gestures out of the box. Route groups are better for persistent, independently-navigable sections.

2. **react-native-pager-view over ScrollView-based pager**: PagerView uses native ViewPager (Android) / UIPageViewController (iOS) under the hood — smooth, lazy-renders pages, and handles swipe gestures natively with proper edge bouncing. A horizontal ScrollView would need manual snap points and doesn't gate forward swiping as cleanly.

3. **Screen sub-components in `src/onboarding/screens/`**: Each page's content lives in its own file for readability, but they're stateless — they receive props from the parent pager and call callbacks up. The pager file (`app/onboarding.tsx`) orchestrates state and navigation.

4. **Pre-built demo content as static JSON over runtime generation**: Zero latency, zero network dependency, deterministic. The 28 responses are small strings + SVG path data. Total bundle cost: <50KB.

5. **Existing profileStore/useProfile for persistence**: The `saveProfile`, `markFirstRunComplete`, and `isFirstRun` functions already exist and handle the exact use case. No new storage layer needed.

6. **Lottie for Suri over inline RN Animated**: The spec mentions Lottie (<200KB total). Lottie files are designer-exportable, support complex character animations (breathing, waving, celebrating), and have built-in reduceMotion support. Placeholder SVGs can stand in until final Lottie assets arrive.

7. **react-native-reanimated over Animated API**: Reanimated runs on the UI thread (no bridge), supports `reduceMotion` natively, and is the standard for Expo 54+ projects.


## Components and Interfaces

### OnboardingScreen (app/onboarding.tsx) — the pager parent
```typescript
// State managed locally via useReducer
interface OnboardingState {
  gradeLevel: number | null;
  responseMode: ResponseMode | null;
  currentPage: number;
  startTimestamp: number;
}

type OnboardingAction =
  | { type: 'SET_GRADE'; grade: number }
  | { type: 'SET_MODE'; mode: ResponseMode }
  | { type: 'GO_TO_PAGE'; page: number }
  | { type: 'RESET_MODE' };
```
Owns PagerView ref, state, and renders ProgressDots + screen components as pages.

### Screen Sub-Components (src/onboarding/screens/*.tsx)
Each screen component is stateless — receives props and calls callbacks:
```typescript
// Example: GradeScreen
interface GradeScreenProps {
  selectedGrade: number | null;
  onSelectGrade: (grade: number) => void;
  onNext: () => void;
  reduceMotion: boolean;
}

// Example: ModeScreen
interface ModeScreenProps {
  onSelectMode: (mode: ResponseMode) => void;
  onSkip: () => void;
  reduceMotion: boolean;
}

// Example: DemoScreen
interface DemoScreenProps {
  gradeLevel: number;
  responseMode: ResponseMode;
  reduceMotion: boolean;
  onNext: () => void;
  onTTSStatus: (played: boolean) => void;
  onSVGStatus: (rendered: boolean) => void;
}
```

### ProgressDots (src/onboarding/components/ProgressDots.tsx)
```typescript
interface ProgressDotsProps {
  total: number;        // Always 6
  current: number;      // 0-indexed
}
```

### SuriMascot (src/onboarding/components/SuriMascot.tsx)
```typescript
type SuriPose = 'wave' | 'confident' | 'curious' | 'thinking' | 'celebrating' | 'proud';

interface SuriMascotProps {
  pose: SuriPose;
  size?: 'small' | 'medium' | 'large';  // large = ~40% viewport
}
```
Internally detects reduceMotion and renders static fallback image when enabled.

### GradeGrid (src/onboarding/components/GradeGrid.tsx)
```typescript
interface GradeGridProps {
  selectedGrade: number | null;
  onSelectGrade: (grade: number) => void;
}
```
Renders grades 4–10 in a responsive grid (2 or 3 columns). Each button is min 48dp height with selected state showing border + checkmark.

### ModeCardGrid (src/onboarding/components/ModeCardGrid.tsx)
```typescript
interface ModeCardGridProps {
  onSelectMode: (mode: ResponseMode) => void;
}
```
Renders 4 cards in 2×2 grid. Each card: icon + Filipino label + one-line description. Cards are min 64dp height.

### MockChat (src/onboarding/components/MockChat.tsx)
```typescript
interface MockChatProps {
  question: string;
  responseMode: ResponseMode;
  demoContent: OnboardingDemoResponse;
}
```
Renders a simplified chat UI with a student bubble and Suri's response bubble. Delegates response rendering to mode-specific sub-components.

### DemoResponse variants
```typescript
// Shared interface for all demo response components
interface DemoResponseProps {
  content: OnboardingDemoResponse;
  onTTSStatus?: (played: boolean) => void;
  onSVGStatus?: (rendered: boolean) => void;
}
```

### DepEdBadge (src/onboarding/components/DepEdBadge.tsx)
```typescript
interface DepEdBadgeProps {
  animate?: boolean;  // false when reduceMotion
}
```

### Onboarding Analytics (src/onboarding/analytics.ts)
```typescript
function trackOnboardingEvent(event: OnboardingEvent): Promise<void>;

type OnboardingEvent =
  | { name: 'onboarding_started'; timestamp: number }
  | { name: 'onboarding_offline_viewed'; timestamp: number }
  | { name: 'onboarding_grade_selected'; grade: number; timestamp: number }
  | { name: 'onboarding_mode_selected'; mode: string; wasSkip: boolean; timestamp: number }
  | { name: 'onboarding_demo_played'; grade: number; mode: string; ttsPlayed: boolean; svgRendered: boolean }
  | { name: 'onboarding_completed'; totalDurationMs: number; mode: string; grade: number };
```

### useReduceMotion (src/onboarding/useReduceMotion.ts)
```typescript
function useReduceMotion(): boolean;
```
Uses React Native's `AccessibilityInfo.isReduceMotionEnabled()` listener. Returns `true` when the OS setting is active.

## Data Models

### OnboardingDemoResponse (src/onboarding/types.ts)
```typescript
interface OnboardingDemoResponse {
  gradeLevel: number;                         // 4–10
  mode: 'visual' | 'auditory' | 'reading' | 'mixed';
  question: string;                           // Filipino — student bubble text
  responseText: string;                       // Filipino — Suri's text response
  svgPaths?: SvgDiagramSpec;                  // For visual/mixed modes
  ttsText?: string;                           // For auditory mode — text read aloud
  textFallback?: string;                      // Fallback if SVG fails
}

interface SvgDiagramSpec {
  viewBox: string;
  elements: SvgElement[];
}

interface SvgElement {
  type: 'path' | 'circle' | 'rect' | 'text' | 'line';
  props: Record<string, string | number>;
}
```

### LearningProfile (existing: src/profile/types.ts)
Already defined — the onboarding flow produces a `LearningProfile` object on completion using the existing interface.

### Analytics Event Schema (expo-sqlite table)
```sql
CREATE TABLE IF NOT EXISTS onboarding_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_name TEXT NOT NULL,
  properties TEXT NOT NULL,  -- JSON string
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
```

## Correctness Properties

### Property 1: No Partial Persistence
Onboarding state is never written to storage mid-flow. If the app closes before Screen 6 CTA, the next launch restarts from Screen 1 with a clean slate.
**Validates: Requirements 12.1**

### Property 2: Grade Selection Required
The pager blocks forward navigation (swipe and CTA) from Page 2 until `gradeLevel !== null`.
**Validates: Requirements 4.1**

### Property 3: Mode Defaults to Mixed
If the user skips the mode picker or swipes back to reset, `responseMode` defaults to `'mixed'` at completion.
**Validates: Requirements 5.5**

### Property 4: Demo Content Always Resolves
`getDemoContent(grade, mode)` has a fallback (Grade 6 Mixed) — it never returns undefined.
**Validates: Requirements 6.1**

### Property 5: TTS Failure Non-Blocking
If expo-speech fails, text still renders and analytics logs `ttsPlayed: false`. No crash or blank screen.
**Validates: Requirements 6.3**

### Property 6: Atomic Profile Save
`saveProfile()` and `markFirstRunComplete()` are both called before navigation. If either fails, the user stays on Screen 6 with a retry option.
**Validates: Requirements 7.1**

## Error Handling

| Error Scenario | Handling Strategy |
|---|---|
| TTS engine unavailable (Screen 5, auditory) | Catch expo-speech error, show text response normally + small fallback note "I-check ang TTS settings ng phone mo". Log `ttsPlayed: false` in analytics. |
| SVG render failure (Screen 5, visual/mixed) | Wrap SVG in error boundary, fall back to `textFallback` string from demo content. Log `svgRendered: false`. |
| expo-secure-store write fails (Screen 6) | Retry once. If still fails, show a gentle error ("Hindi ko na-save. Subukan ulit?") with retry button. Do not navigate away until profile is saved. |
| AccessibilityInfo not available | Default `reduceMotion` to `false` (animations play). |
| App killed mid-onboarding | No partial state is persisted. Next launch starts fresh from Screen 1. This is by design. |

## Testing Strategy

### Unit Tests
- `OnboardingContext` reducer: verify state transitions for each action type
- `demoContent.ts`: verify all 28 entries exist, have required fields, match type constraints
- `analytics.ts`: verify events are written to sqlite with correct shape

### Component Tests (React Native Testing Library)
- Each screen component renders correct copy and interactive elements
- GradeGrid: selection state, disabled button when no selection
- ModeCardGrid: each card triggers correct mode
- MockChat: renders correct demo content for grade × mode combination
- ProgressDots: highlights correct dot for each screen index

### Integration Tests
- Full flow: Screen 1 → 6 with grade and mode selection → profile saved correctly
- First-run gate: app redirects to onboarding when isFirstRun() is true
- Skip behavior: "Laktawan" on Screen 4 sets mode to 'mixed' and advances

### Manual Verification
- Airplane mode: complete full onboarding with no connectivity
- Reduce motion: verify static images replace all animations
- TTS: verify audio plays on Screen 5 in auditory mode
- Device sizes: verify layout on 4.7" (iPhone SE) through 6.7" (iPhone 15 Pro Max)

/**
 * Single learning mode card for the mode picker.
 * Shows an icon, Filipino label, and one-line description.
 * Min 64dp height, min 48dp touch target.
 */
import { Pressable, StyleSheet, Text, View } from 'react-native';

interface ModeCardProps {
  icon: string;
  label: string;
  description: string;
  onPress: () => void;
}

export function ModeCard({ icon, label, description, onPress }: ModeCardProps) {
  return (
    <Pressable
      style={({ pressed }) => [styles.card, pressed && styles.cardPressed]}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${label}: ${description}`}
    >
      <Text style={styles.icon}>{icon}</Text>
      <View style={styles.textContainer}>
        <Text style={styles.label}>{label}</Text>
        <Text style={styles.description}>{description}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minHeight: 48,
    minWidth: 140,
    padding: 10,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: '#E8DDD0',
    backgroundColor: '#FFF9F2',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  cardPressed: {
    borderColor: '#F27A3A',
    backgroundColor: '#FFF0E6',
    transform: [{ scale: 0.97 }],
  },
  icon: {
    fontSize: 24,
  },
  textContainer: {
    alignItems: 'center',
  },
  label: {
    fontSize: 15,
    fontWeight: '600',
    color: '#4A3728',
  },
  description: {
    fontSize: 12,
    color: '#7A6A5A',
    textAlign: 'center',
    marginTop: 2,
  },
});

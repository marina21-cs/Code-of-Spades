/**
 * DepEd curriculum badge with animated checkmark.
 * Respects reduce-motion — shows static completed state when motion disabled.
 * Marked as decorative (not announced by screen readers).
 */
import { useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import Svg, { Circle, Path, Text as SvgText } from 'react-native-svg';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withTiming,
} from 'react-native-reanimated';

import { useReduceMotion } from '../useReduceMotion';

export function DepEdBadge() {
  const reduceMotion = useReduceMotion();
  const checkOpacity = useSharedValue(reduceMotion ? 1 : 0);
  const checkScale = useSharedValue(reduceMotion ? 1 : 0.5);

  useEffect(() => {
    if (!reduceMotion) {
      checkOpacity.value = withDelay(400, withTiming(1, { duration: 500 }));
      checkScale.value = withDelay(400, withTiming(1, { duration: 500 }));
    }
  }, [reduceMotion, checkOpacity, checkScale]);

  const checkAnimatedStyle = useAnimatedStyle(() => ({
    opacity: checkOpacity.value,
    transform: [{ scale: checkScale.value }],
  }));

  return (
    <View
      style={styles.container}
      importantForAccessibility="no"
      accessibilityElementsHidden
    >
      {/* Badge seal */}
      <Svg width={120} height={120} viewBox="0 0 120 120">
        {/* Outer ring */}
        <Circle cx={60} cy={60} r={55} fill="none" stroke="#1B5E20" strokeWidth={3} />
        <Circle cx={60} cy={60} r={48} fill="none" stroke="#2E7D32" strokeWidth={1.5} />
        {/* Inner fill */}
        <Circle cx={60} cy={60} r={44} fill="#E8F5E9" />
        {/* DepEd text */}
        <SvgText x={60} y={50} textAnchor="middle" fontSize={11} fontWeight="bold" fill="#1B5E20">
          DepEd
        </SvgText>
        <SvgText x={60} y={65} textAnchor="middle" fontSize={8} fill="#2E7D32">
          Curriculum
        </SvgText>
        <SvgText x={60} y={78} textAnchor="middle" fontSize={7} fill="#4CAF50">
          Verified Content
        </SvgText>
      </Svg>

      {/* Animated checkmark overlay */}
      <Animated.View style={[styles.checkOverlay, checkAnimatedStyle]}>
        <Svg width={40} height={40} viewBox="0 0 40 40">
          <Circle cx={20} cy={20} r={18} fill="#4CAF50" />
          <Path
            d="M12 20 L18 26 L28 14"
            stroke="#FFF"
            strokeWidth={3}
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />
        </Svg>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  checkOverlay: {
    position: 'absolute',
    bottom: -5,
    right: -5,
  },
});

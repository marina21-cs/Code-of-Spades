# Requirements Document

## Introduction
This document defines requirements for the Suri Onboarding feature — a 6-screen first-run flow that introduces the Suri fox mascot, personalizes grade level and learning mode, demonstrates AI responses live with grade-appropriate DepEd curriculum content, and reveals curriculum grounding. Target users are Filipino students Grades 4–10, many in rural areas with limited connectivity. The onboarding must work fully offline, require zero account creation, and complete in under 90 seconds.

## Glossary
- **Suri**: The fox mascot AI study buddy
- **DepEd MELC**: Department of Education Minimum Essential Learning Competencies (Philippines K-12 curriculum)
- **Response Mode**: How Suri formats answers — visual (diagrams), auditory (TTS), reading (structured text), or mixed
- **expo-secure-store**: Encrypted local key-value storage on device
- **TTS**: Text-to-speech via expo-speech

## Requirements

### Requirement 1: First-Run Gate
#### Description
When a first-time user launches the app (`onboardingComplete` is `false` or missing in expo-secure-store), the onboarding flow (Screen 1) appears instead of the main app. Users who have completed onboarding land directly on the Chat tab.
#### Acceptance Criteria
- GIVEN a first-time user launches the app, WHEN `onboardingComplete` is `false` or missing, THEN the onboarding flow (Screen 1) appears instead of the main app.
- GIVEN a user has completed onboarding, WHEN they relaunch the app, THEN they land directly on the Chat tab (onboarding does not repeat).

### Requirement 2: Screen 1 — Meet Suri (Welcome)
#### Description
Display a warm introduction screen with the Suri fox mascot in an idle/wave animation, the app name, tagline ("Kasama mo ako sa pag-aaral — kahit walang internet"), and a single CTA button ("Tara, kilalanin mo ako!") that advances to Screen 2. Respects reduce-motion by showing a static image instead.
#### Acceptance Criteria
- GIVEN Screen 1 is displayed, WHEN the user taps "Tara, kilalanin mo ako!", THEN the app navigates to Screen 2.
- GIVEN the device has OS-level reduce-motion enabled, WHEN Screen 1 loads, THEN Suri is displayed as a static image (no breathing/wave animation).
- GIVEN Screen 1, THEN no back button is visible (this is the first screen).

### Requirement 3: Screen 2 — Feature Showcase (Works Offline)
#### Description
Show Suri's primary value proposition: she works without internet. Display an animated sequence of signal bars dropping to zero while Suri stays active. Include a "Susunod" (Next) button and a "Laktawan" (Skip) link that both advance to Screen 3.
#### Acceptance Criteria
- GIVEN the user is on Screen 2, WHEN they tap "Susunod", THEN the app navigates to Screen 3.
- GIVEN the user is on Screen 2, WHEN they tap "Laktawan" (Skip), THEN the app jumps directly to Screen 3 (Grade Level Picker).
- GIVEN the device has reduce-motion enabled, THEN the signal bar animation is replaced with a static illustration.

### Requirement 4: Screen 3 — Grade Level Picker
#### Description
Suri asks the student's grade level via a tappable grid of grade buttons (Grade 4 through Grade 10). Selection is required — no skip option. The "Susunod" button enables only after a grade is selected. Grade selection is retained when swiping back.
#### Acceptance Criteria
- GIVEN Screen 3 is displayed, WHEN no grade is selected, THEN the "Susunod" button is disabled or hidden.
- GIVEN the user taps a grade button, THEN that button shows a selected state (border/fill change + checkmark), AND the "Susunod" button becomes enabled.
- GIVEN a grade is selected AND the user taps "Susunod", THEN the grade is stored temporarily in component state AND the app navigates to Screen 4.
- GIVEN the user swipes back from Screen 4 to Screen 3, THEN the previously selected grade is retained.

### Requirement 5: Screen 4 — Learning Mode Picker
#### Description
Present 4 learning mode cards in a 2×2 grid: Tignan (Visual), Pakinggan (Auditory), Basahin (Reading), Halo-halo (Mixed). Tapping any card selects the mode and advances to Screen 5. A "Laktawan" skip link defaults to Mixed mode.
#### Acceptance Criteria
- GIVEN the user taps "Tignan" (Visual), THEN `responseMode = 'visual'` AND the app navigates to Screen 5.
- GIVEN the user taps "Pakinggan" (Auditory), THEN `responseMode = 'auditory'` AND the app navigates to Screen 5.
- GIVEN the user taps "Basahin" (Reading), THEN `responseMode = 'reading'` AND the app navigates to Screen 5.
- GIVEN the user taps "Halo-halo" (Mixed), THEN `responseMode = 'mixed'` AND the app navigates to Screen 5.
- GIVEN the user taps "Laktawan" (Skip), THEN `responseMode = 'mixed'` AND the app navigates to Screen 5.
- GIVEN the user swipes back from Screen 5 to Screen 4, THEN the mode selection resets to no selection.

### Requirement 6: Screen 5 — Study Buddy Live Demo
#### Description
Display a mock chat interface showing a pre-filled student question (grade-appropriate from DepEd MELCs) and Suri's response rendered in the student's chosen learning mode. 7 grades × 4 modes = 28 pre-built demo responses bundled in the app. No network calls. TTS auto-plays for auditory mode with graceful fallback.
#### Acceptance Criteria
- GIVEN the user selected Grade 6 and Visual mode, WHEN Screen 5 loads, THEN the mock chat shows a Grade 6 Science question with an SVG diagram response.
- GIVEN the user selected Auditory mode, WHEN Screen 5 loads, THEN TTS auto-plays the demo response AND an audio wave animation appears around Suri.
- GIVEN TTS fails on Screen 5 (auditory demo), THEN the text response still appears normally and a fallback message is shown.
- GIVEN Visual/Mixed mode AND SVG fails to render, THEN a text description fallback appears (no error state shown to user).
- GIVEN the device has no network connectivity, THEN Screen 5 renders correctly (all content is bundled).

### Requirement 7: Screen 6 — DepEd Curriculum Reveal and Completion
#### Description
Show a DepEd badge/seal with a verified checkmark animation. Reveal that the demo answer came from official DepEd curriculum. On tapping "Tara mag-aral!", persist the full LearningProfile to expo-secure-store and navigate to the main Chat tab.
#### Acceptance Criteria
- GIVEN the user taps "Tara mag-aral!" on Screen 6, THEN the full LearningProfile is persisted to `expo-secure-store` with the chosen mode, grade, and default accessibility settings.
- GIVEN the user taps "Tara mag-aral!", THEN `onboardingComplete` is set to `true` (via `markFirstRunComplete()`).
- GIVEN the profile is saved, THEN navigation transitions to the main app (Chat tab).

### Requirement 8: Navigation and Progress UX
#### Description
All 6 screens share consistent navigation: progress dots at bottom (current highlighted), swipe left/right between screens via gesture handler, and all interactive elements meet 48dp minimum touch target size. Forward swipe is gated by screen completion.
#### Acceptance Criteria
- GIVEN any onboarding screen, THEN 6 progress dots are visible at the bottom with the current screen highlighted.
- GIVEN any screen except Screen 1, THEN the user can swipe right (back) to the previous screen.
- GIVEN any screen except Screen 6, THEN the user can swipe left (forward) only after completing that screen's required action.
- All interactive elements have minimum 48dp touch targets.
- All text passes WCAG AA contrast ratio (4.5:1 body text, 3:1 large text).

### Requirement 9: Accessibility — Reduce Motion
#### Description
Respect the OS-level reduce-motion / "Remove animations" setting even before the profile is created. When enabled, replace all Suri animations with static images and all screen transitions with simple crossfades.
#### Acceptance Criteria
- GIVEN the device has OS-level reduce-motion enabled, WHEN onboarding loads, THEN Suri is displayed as a static image on all screens.
- GIVEN reduce-motion is enabled, THEN all screen transitions are simple opacity crossfades (no slide transforms).
- GIVEN reduce-motion is enabled on Screen 5 (auditory mode), THEN the audio wave animation is suppressed (TTS still plays).

### Requirement 10: Zero Friction and Privacy
#### Description
The onboarding collects no personal data, makes no network requests, requests no device permissions, shows no paywall or upgrade prompt, and requires no account creation.
#### Acceptance Criteria
- GIVEN the entire onboarding flow, THEN no network requests are made at any point.
- No screen in the onboarding requests any device permissions (camera, microphone, notifications, location).
- No screen shows a paywall, upgrade prompt, or payment request.
- No account creation, email, phone number, or sign-in is requested.

### Requirement 11: Local Analytics Tracking
#### Description
Track onboarding events locally in expo-sqlite for potential future sync: onboarding_started, onboarding_offline_viewed, onboarding_grade_selected, onboarding_mode_selected, onboarding_demo_played, onboarding_completed with relevant properties.
#### Acceptance Criteria
- GIVEN Screen 1 appears, THEN an `onboarding_started` event with timestamp is written to expo-sqlite.
- GIVEN Screen 2 appears, THEN an `onboarding_offline_viewed` event is logged.
- GIVEN a grade is tapped on Screen 3, THEN an `onboarding_grade_selected` event with `{ grade, timestamp }` is logged.
- GIVEN a mode is selected/skipped on Screen 4, THEN an `onboarding_mode_selected` event with `{ mode, wasSkip, timestamp }` is logged.
- GIVEN Screen 5 auto-plays, THEN an `onboarding_demo_played` event with `{ grade, mode, ttsPlayed, svgRendered }` is logged.
- GIVEN "Tara mag-aral!" is tapped on Screen 6, THEN an `onboarding_completed` event with `{ totalDurationMs, mode, grade }` is logged.

### Requirement 12: Interruption Handling
#### Description
If the student force-closes the app mid-onboarding, on next launch onboarding restarts from Screen 1 (no partial state saved). The full flow takes under 90 seconds at a comfortable pace.
#### Acceptance Criteria
- GIVEN the student force-closes the app mid-onboarding, WHEN they relaunch, THEN onboarding restarts from Screen 1.
- GIVEN the entire onboarding flow measured end-to-end, THEN a student can complete it in under 90 seconds at a comfortable pace.

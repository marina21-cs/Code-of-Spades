/**
 * Type definitions for the onboarding flow.
 *
 * The onboarding is a 6-screen pager that collects grade level and learning
 * mode, then persists a LearningProfile via the existing profileStore.
 * State is ephemeral (not persisted mid-flow) — if the app closes, onboarding
 * restarts from Screen 1.
 */
import type { ResponseMode } from '@/profile/types';

// Re-export for convenience within onboarding module
export type { ResponseMode } from '@/profile/types';

// ---------------------------------------------------------------------------
// Onboarding State (managed by useReducer in the pager)
// ---------------------------------------------------------------------------

export interface OnboardingState {
  /** Selected grade (4–10), null until Screen 3 selection. */
  gradeLevel: number | null;
  /** Selected learning mode, null until Screen 4 selection. */
  responseMode: ResponseMode | null;
  /** Current pager page index (0–5). */
  currentPage: number;
  /** Timestamp (Date.now()) when onboarding started, for duration analytics. */
  startTimestamp: number;
}

export type OnboardingAction =
  | { type: 'SET_GRADE'; grade: number }
  | { type: 'SET_MODE'; mode: ResponseMode }
  | { type: 'GO_TO_PAGE'; page: number }
  | { type: 'RESET_MODE' };

// ---------------------------------------------------------------------------
// Screen Props (stateless screen sub-components receive these from the pager)
// ---------------------------------------------------------------------------

export interface WelcomeScreenProps {
  onNext: () => void;
  reduceMotion: boolean;
}

export interface OfflineScreenProps {
  onNext: () => void;
  onSkip: () => void;
  reduceMotion: boolean;
}

export interface GradeScreenProps {
  selectedGrade: number | null;
  onSelectGrade: (grade: number) => void;
  onNext: () => void;
  reduceMotion: boolean;
}

export interface ModeScreenProps {
  onSelectMode: (mode: ResponseMode) => void;
  onSkip: () => void;
  reduceMotion: boolean;
}

export interface DemoScreenProps {
  gradeLevel: number;
  responseMode: ResponseMode;
  reduceMotion: boolean;
  onNext: () => void;
  onTTSStatus: (played: boolean) => void;
  onSVGStatus: (rendered: boolean) => void;
}

export interface CurriculumScreenProps {
  onComplete: () => void;
  reduceMotion: boolean;
}

// ---------------------------------------------------------------------------
// Demo Content (bundled responses for Screen 5)
// ---------------------------------------------------------------------------

/** A single SVG element spec for rendering with react-native-svg. */
export interface SvgElement {
  type: 'path' | 'circle' | 'rect' | 'text' | 'line' | 'ellipse' | 'polygon';
  props: Record<string, string | number>;
  /** For 'text' type elements — the text content to render. */
  children?: string;
}

/** SVG diagram specification — enough to render a simple diagram. */
export interface SvgDiagramSpec {
  viewBox: string;
  width?: number;
  height?: number;
  elements: SvgElement[];
}

/** One pre-built demo response (7 grades × 4 modes = 28 total). */
export interface OnboardingDemoResponse {
  gradeLevel: number;
  mode: ResponseMode;
  /** Filipino question shown in the "student" chat bubble. */
  question: string;
  /** Filipino text response from Suri. */
  responseText: string;
  /** SVG diagram spec for visual/mixed modes. */
  svgSpec?: SvgDiagramSpec;
  /** Text for TTS engine to read aloud (auditory mode). */
  ttsText?: string;
  /** Fallback text if SVG fails to render. */
  textFallback?: string;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Grade levels available in onboarding (DepEd Grades 1–12). */
export const ONBOARDING_GRADES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] as const;

/** Total number of onboarding pages. */
export const ONBOARDING_PAGE_COUNT = 6;

/** Mode options shown on Screen 4 (excludes kinesthetic per spec). */
export const ONBOARDING_MODE_OPTIONS: readonly {
  mode: ResponseMode;
  icon: string;
  label: string;
  description: string;
}[] = [
  {
    mode: 'visual',
    icon: '👁️',
    label: 'Tignan',
    description: 'Mas gusto ko makita sa drawing.',
  },
  {
    mode: 'auditory',
    icon: '👂',
    label: 'Pakinggan',
    description: 'Mas gusto ko marinig ang explanation.',
  },
  {
    mode: 'reading',
    icon: '📖',
    label: 'Basahin',
    description: 'Mas gusto ko basahin nang maayos.',
  },
  {
    mode: 'mixed',
    icon: '🔀',
    label: 'Halo-halo',
    description: 'Okay lang kahit ano — bahala ka.',
  },
] as const;

/**
 * Screen 6: DepEd Curriculum Reveal + Completion.
 * Shows the trust seal and transitions to the main app on CTA tap.
 */
import { StyleSheet, Text, View } from 'react-native';

import { DepEdBadge } from '../components/DepEdBadge';
import { SuriMascot } from '../components/SuriMascot';
import type { CurriculumScreenProps } from '../types';

export function CurriculumScreen({ reduceMotion }: CurriculumScreenProps) {
  return (
    <View style={styles.container}>
      <DepEdBadge />

      <SuriMascot pose="proud" size="small" />

      <Text style={styles.reveal}>
        {'Yung sagot ko kanina?\nGaling \'yan sa DepEd curriculum mo.'}
      </Text>

      <Text style={styles.body}>
        {'Hindi ako nag-iimbento.\nLahat ng alam ko, galing sa\nopisyal na lessons ng school mo.'}
      </Text>

      <Text style={styles.note}>
        Pwede mong baguhin kung paano kausap mo ako anytime sa Settings.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    gap: 16,
  },
  reveal: {
    fontSize: 17,
    fontWeight: '600',
    color: '#4A3728',
    textAlign: 'center',
    lineHeight: 25,
  },
  body: {
    fontSize: 15,
    color: '#6A5A4A',
    textAlign: 'center',
    lineHeight: 23,
  },
  note: {
    fontSize: 13,
    color: '#9A7A5A',
    textAlign: 'center',
    fontStyle: 'italic',
    marginTop: 8,
  },
});
